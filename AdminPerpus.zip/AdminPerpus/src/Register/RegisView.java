/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Register;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.util.Random;
import javax.swing.*;
import static javax.swing.JFrame.EXIT_ON_CLOSE;

/**
 *
 * @author HP
 */
public class RegisView extends JFrame{
    JLabel ljudul1,luser,lpass,lconfirm,lnama,ltlp,lid;
    JTextField txuname,txnama,txtlp,txid;
    JPasswordField pfpw,pfcpw;
    JButton back, regis;
    
    public RegisView(){
        Image image = new ImageIcon(getClass().getResource("bg3.jpg")).getImage();
         this.setContentPane(new JPanel() {
         @Override
            public void paintComponent(Graphics g) {
               super.paintComponent(g);
               g.drawImage(image, 0, 0, 580,510, null);
            }
         }); 
        setTitle("Register User");
        
        ljudul1 = new JLabel("Register ");
        luser = new JLabel("Username");
        lpass = new JLabel("Passwoard");
        lconfirm = new JLabel("Konfirmasi Password");
        lnama = new JLabel("Nama Lengkap");
        ltlp = new JLabel("No. Telp");
        lid = new JLabel("Id User");
        
        Random idRandom = new Random();
        int id = 1000000 + idRandom.nextInt( 9999999 );
        txid = new JTextField(Integer.toString(id));
        txuname = new JTextField();
        txnama = new JTextField();
        txtlp = new JTextField();
        pfpw = new JPasswordField();
        pfcpw = new JPasswordField();
        
        txid.setEditable(false);
        
        back = new JButton("Kembali");
        regis = new JButton("Simpan");
        
        Font font = new Font("Tahoma", 1, 14);
        Font font1 = new Font("Tahoma", 1, 30);
        luser.setFont(font);
        lpass.setFont(font);
        ljudul1.setFont(font1);
        lconfirm.setFont(font);
        lnama.setFont(font);
        ltlp.setFont(font);
        lid.setFont(font);
        
        luser.setForeground(Color.WHITE);
        lpass.setForeground(Color.WHITE);
        lconfirm.setForeground(Color.WHITE);
        lnama.setForeground(Color.WHITE);
        ljudul1.setForeground(Color.WHITE);
        ltlp.setForeground(Color.WHITE);
        lid.setForeground(Color.WHITE);
        
        setLayout(null);
        add(ljudul1);
        add(lid);
        add(luser);
        add(lpass);
        add(lnama);
        add(ltlp);
        add(lconfirm);
        add(txtlp);
        add(txid);
        add(txuname);
        add(txnama);
        add(pfpw);
        add(pfcpw);
        add(back);
        add(regis);
        
        ljudul1.setBounds(100, 30, 300, 50);
        lid.setBounds(100, 100, 200, 25);
        lnama.setBounds(100, 150, 200, 25);
        ltlp.setBounds(100, 200, 100, 25);
        luser.setBounds(100, 250, 100, 25);
        lpass.setBounds(100, 300, 100, 25);
        lconfirm.setBounds(100, 350, 200, 25);
        txid.setBounds(250, 100, 200, 30);
        txnama.setBounds(250, 150, 200, 30);
        txtlp.setBounds(250, 200, 200, 30);
        txuname.setBounds(250, 250, 200, 30);
        pfpw.setBounds(250, 300, 200, 30);
        pfcpw.setBounds(250, 350, 200, 30);
        back.setBounds(120, 400, 90, 30);
        regis.setBounds(330, 400, 90, 30);
        
        setSize(580,510);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    
    public String getUname(){
        return txuname.getText();
    }
     
    public String getNama(){
        return txnama.getText();
    }
    
    public String getTelp(){
        return txtlp.getText();
    }
     
    public String getPw(){
         String pass = new String(pfpw.getPassword());
         return pass;
//        return pw.getPassword().toString();
    }
    
    public String getCpw(){
         String cpass = new String(pfcpw.getPassword());
         return cpass;
//        return pw.getPassword().toString();
    }
    
    public String getIdUser(){
        return txid.getText();
    }
}


