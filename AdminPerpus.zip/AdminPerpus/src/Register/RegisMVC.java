/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Register;

/**
 *
 * @author HP
 */
public class RegisMVC {
    RegisView regisview = new RegisView();
    RegisController regiscontroller = new RegisController(regisview);
}
