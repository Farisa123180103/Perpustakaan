/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Register;

import Login.LoginUserMVC;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
import javax.swing.*;

public class RegisController {
    RegisView regisview;
    private Connection koneksi;
    private Statement statement;
    
    public RegisController(RegisView regisview){
        this.regisview = regisview;
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost/perpustakaan";
            koneksi = DriverManager.getConnection(url, "root", "");
            statement = koneksi.createStatement();
        } catch (ClassNotFoundException ex){
            JOptionPane.showMessageDialog(null, "Class Not Found : " + ex);
        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null, "SQL Exception : " + ex);
        }
        
        regisview.regis.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                String uname = regisview.getUname();
                String pw = regisview.getPw();
                String nama = regisview.getNama();
                String cpw = regisview.getCpw();
                String tlp = regisview.getTelp();
                
                try {
                    if(uname.isEmpty() || pw.isEmpty() || cpw.isEmpty() || nama.isEmpty() || tlp.isEmpty()){
                    JOptionPane.showMessageDialog(null, "Mohon Lengkapi Data");
                    } else if(!pw.equals(cpw) ){
                    JOptionPane.showMessageDialog(null, "Password dan Konfirmasi Password Tidak Sama");
                    }else {
                        String query = "INSERT INTO user VALUES ('"+regisview.getIdUser()+"','"+regisview.getNama()+
                        "','"+regisview.getUname()+"','"+regisview.getPw()+
                        "','"+regisview.getTelp()+"')";
                        statement.executeUpdate(query);
                        JOptionPane.showMessageDialog(null, "Data disimpan");
                        regisview.txid.setText("");
                        regisview.txnama.setText("");
                        regisview.txtlp.setText("");
                        regisview.txuname.setText("");
                        regisview.pfpw.setText("");
                        regisview.pfcpw.setText("");
                    }
                } catch(Exception sql){
                    JOptionPane.showMessageDialog(null, sql.getMessage());
                }
                
            }
        });
        
         regisview.back.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                regisview.setVisible(false);
                new LoginUserMVC();
            }
        });
    }
}
