/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package User;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class DashboardView extends JFrame{
    private Image image;
    JLabel lsearch,luser;
    JButton dboard, buku , pinjam, logout;
    JTextArea ket;
    
    public DashboardView(String uname){
        image = new ImageIcon(getClass().getResource("bg4.jpg")).getImage();
         this.setContentPane(new JPanel() {
         @Override
            public void paintComponent(Graphics g) {
               super.paintComponent(g);
               g.drawImage(image, 0, 0, 780, 450, null);
            }
         }); 
        setTitle("Data Buku");
        
        
        luser = new JLabel(uname);
        
        dboard = new JButton("DASHBOARD");
        buku = new JButton("BUKU");
        pinjam = new JButton("PINJAMAN");
        logout = new JButton("LOGOUT");
        
        ket = new JTextArea("Selamat Datang "+uname+"\n Ayo Membaca...\n\n \t Cuman perlu satu buku \n \t "
                + "untuk jatuh cinta pada membaca. \n \t Cari buku itu. Mari jatuh cinta \n \t\t "
                + "-Najwa Shihab");
        ket.setEditable(false);
        
        //edit font
        Font font = new Font("Tahoma", 1, 14);
        Font font1 = new Font("Tahoma", 1, 20);
        luser.setFont(font);
        ket.setFont(font1);
        
        setLayout(null);
        add(luser);
        add(dboard);
        add(buku);
        add(pinjam);
        add(logout);
        add(ket);
        
        luser.setBounds(100, 400, 100, 25);
        dboard.setBounds(20, 20, 150, 30);
        buku.setBounds(20, 60, 150, 30);
        pinjam.setBounds(20, 100, 150, 30);
        logout.setBounds(20, 140, 150, 30);
        ket.setBounds(210, 30, 530, 250);
        
        setSize(780,450);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    
}



