/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package User;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author HP
 */
public class BukuDAO {
    private int jmlData;
    private Connection koneksi;
    private Statement statement;
    //constructor berfungsi utk melakukan sebuah koneksi saat ada object baru dibuat
    public BukuDAO(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost/perpustakaan";
            koneksi = DriverManager.getConnection(url, "root", "");
            statement = koneksi.createStatement();
        } catch (ClassNotFoundException ex){
            JOptionPane.showMessageDialog(null, "Class Not Found : " + ex);
        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null, "SQL Exception : " + ex);
        }
    }
    
    public String[][] Cari(BukuView view){
        try{
            int Data = 0;
            String data[][] = new String[getJmldatacari(view)][8];
            String query = "SELECT * FROM buku WHERE judul_buku LIKE '%"+view.getSearch()+"%'";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                data[Data][0] = resultSet.getString("id_buku");
                data[Data][1] = resultSet.getString("judul_buku");
                data[Data][2] = resultSet.getString("genre");
                data[Data][3] = resultSet.getString("pengarang");
                data[Data][4] = resultSet.getString("penerbit");
                data[Data][5] = resultSet.getString("tahun");
                data[Data][6] = resultSet.getString("stok");
                Data++;
            }
            return data;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return null;
        }
    }
    
    public String[][] readBuku(){
        try{
            int jmlData = 0;
            String data[][] = new String[getJmldata()][8];
            String query = "SELECT * FROM buku";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                data[jmlData][0] = resultSet.getString("id_buku");
                data[jmlData][1] = resultSet.getString("judul_buku");
                data[jmlData][2] = resultSet.getString("genre");
                data[jmlData][3] = resultSet.getString("pengarang");
                data[jmlData][4] = resultSet.getString("penerbit");
                data[jmlData][5] = resultSet.getString("tahun");
                data[jmlData][6] = resultSet.getString("stok");
                jmlData++;
            }
            return data;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return null;
        }
    }
    
    public int getJmldata(){
        int jmlData = 0;
        try{
            String query = "SELECT * FROM buku";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                jmlData++;
            }
             return jmlData;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return 0;
        }
    }
    
    public int getJmldatacari(BukuView view){
        int jmlData = 0;
        try{
            String query = "SELECT * FROM buku WHERE judul_buku LIKE '%"+view.getSearch()+"%'";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                jmlData++;
            }
             return jmlData;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return 0;
        }
    }

    
}
