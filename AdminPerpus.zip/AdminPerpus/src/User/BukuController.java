/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package User;


import Login.LoginUserMVC;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.Statement;
import javax.swing.*;

public class BukuController {

    BukuView bukuview;
    BukuDAO bukudao;
    String uname;
    int id;
    private Connection koneksi;
    private Statement statement;
    
    public BukuController(BukuView bukuview, BukuDAO bukudao, String uname, int id){
        this.bukuview = bukuview;
        this.bukudao = bukudao;
        this.uname = uname;
        this.id = id;
        
        if (bukudao.getJmldata() != 0){
            String dataBuku[][] = bukudao.readBuku();
            bukuview.tabel.setModel((new JTable(dataBuku, bukuview.namaKolom)).getModel());
        }else{
            JOptionPane.showMessageDialog(null, "Data Tidak Ada");
        }
        
        bukuview.search.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
              String cari = bukuview.getSearch();
              bukuview.setCari(cari);
              String dataBuku[][] = bukudao.Cari(bukuview);
              bukuview.tabel.setModel((new JTable(dataBuku, bukuview.namaKolom)).getModel());
            }
        });
        
        bukuview.dboard.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                bukuview.setVisible(false);
                DashboardView view = new DashboardView(uname);
                DashboardController controller = new DashboardController(view, uname, id);
            }
        });
        
        bukuview.pinjam.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                bukuview.setVisible(false);
                PinjamDAO dao = new PinjamDAO();
                PinjamView view = new PinjamView();
                PinjamController controller = new PinjamController(view, dao, uname, id);
            }
        });
        
        bukuview.logout.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                bukuview.setVisible(false);
                new LoginUserMVC();
            }
        });
    }
}
