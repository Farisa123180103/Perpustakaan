/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package User;

import Login.LoginUserMVC;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.Statement;
import javax.swing.*;

public class PinjamController {
    PinjamView pinjamview;
    PinjamDAO pinjamdao;
    String uname;
    int id;
    private Connection koneksi;
    private Statement statement;
    
    public PinjamController(PinjamView pinjamview, PinjamDAO pinjamdao, String uname, int id){
        this.pinjamview = pinjamview;
        this.pinjamdao = pinjamdao;
        this.uname = uname;
        this.id = id;
        
        if (pinjamdao.getJmldata(id) != 0){
            String dataPinjam[][] = pinjamdao.readPinjam(id);
            pinjamview.tabel.setModel((new JTable(dataPinjam, pinjamview.namaKolom)).getModel());
        }else{
            JOptionPane.showMessageDialog(null, "Data Tidak Ada");
        }
        
//        pinjamview.search.addActionListener(new ActionListener(){
//            @Override
//            public void actionPerformed(ActionEvent e) {
//              String cari = pinjamview.getSearch();
//              pinjamview.setCari(cari);
//              String dataPinjam[][] = pinjamdao.Cari(pinjamview);
//              pinjamview.tabel.setModel((new JTable(dataPinjam, pinjamview.namaKolom)).getModel());
//            }
//        });
        
        pinjamview.dboard.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                pinjamview.setVisible(false);
                DashboardView view = new DashboardView(uname);
                DashboardController controller = new DashboardController(view, uname, id);
            }
        });
        
        pinjamview.buku.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                pinjamview.setVisible(false);
                BukuDAO dao = new BukuDAO();
                BukuView view = new BukuView();
                BukuController controller = new BukuController(view, dao, uname, id);
            }
        });
        
        pinjamview.logout.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                pinjamview.setVisible(false);
                new LoginUserMVC();
            }
        });
    }
}
