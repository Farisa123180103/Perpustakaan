/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package User;

import Login.LoginUserMVC;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.Statement;
import javax.swing.*;
 
public class DashboardController {
    DashboardView dashboardview;
    String uname;
    int id;
    private Connection koneksi;
    private Statement statement;
    
    public DashboardController(DashboardView dashboardview, String uname, int id){
        this.dashboardview = dashboardview;
        this.uname = uname;
        this.id = id;
        
        dashboardview.buku.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                dashboardview.setVisible(false);
                BukuDAO dao = new BukuDAO();
                BukuView view = new BukuView();
                BukuController controller = new BukuController(view, dao, uname, id);
            }
        });
        
        dashboardview.pinjam.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                dashboardview.setVisible(false);
                PinjamDAO dao = new PinjamDAO();
                PinjamView view = new PinjamView();
                PinjamController controller = new PinjamController(view, dao, uname, id);
            }
        });
        
        dashboardview.logout.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                dashboardview.setVisible(false);
                new LoginUserMVC();
            }
        });
    }
}