/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package User;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class BukuView extends JFrame{
    private Image image;
    JLabel ljudul;
    JTextField txsearch;
    JButton dboard, buku , pinjam, search, logout;
    JTable tabel;
    DefaultTableModel tableModel;
    JScrollPane scrollPane;
    Object namaKolom[] = {"ID","Judul Buku","Genre","Pengarang","Penerbit","Tahun Terbit","Stok"};
    
    public BukuView(){
        image = new ImageIcon(getClass().getResource("bg4.jpg")).getImage();
         this.setContentPane(new JPanel() {
         @Override
            public void paintComponent(Graphics g) {
               super.paintComponent(g);
               g.drawImage(image, 0, 0, 780, 450, null);
            }
         });  
        setTitle("Data Buku");
        
        tableModel = new DefaultTableModel(namaKolom, 0);
        tabel = new JTable(tableModel);
        scrollPane = new JScrollPane(tabel);
        
        ljudul = new JLabel("DATA BUKU");
        
        txsearch = new JTextField();
        
        dboard = new JButton("DASHBOARD");
        buku = new JButton("BUKU");
        pinjam = new JButton("PINJAMAN");
        search = new JButton("SEARCH");
        logout = new JButton("LOGOUT");
        
        //edit font
        Font font1 = new Font("Cooper Black", 1, 26);
        ljudul.setFont(font1);
        ljudul.setForeground(Color.white);
        
        setLayout(null);
        add(scrollPane);
        add(ljudul);
        add(txsearch);
        add(dboard);
        add(buku);
        add(search);
        add(pinjam);
        add(logout);
        
        ljudul.setBounds(350, 30, 200, 40);
        txsearch.setBounds(210, 90, 200, 30);
        dboard.setBounds(20, 20, 150, 30);
        buku.setBounds(20, 60, 150, 30);
        search.setBounds(430, 90, 90, 30);
        pinjam.setBounds(20, 100, 150, 30);
        logout.setBounds(20, 140, 150, 30);
        scrollPane.setBounds(210, 140, 530, 250);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        
        setSize(780,450);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    
    public String getSearch(){
        return txsearch.getText();
    }
    
    public void setCari(String ncari){
        String cari = ncari;
    }
    
    
}



