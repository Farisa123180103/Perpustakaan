
package registrasiadmin;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.util.Random;
import javax.swing.*;


public class RegistrasiAdminView extends JFrame{
    JLabel judul, id_admin, nama, telepon, username, password;
    JTextField txid, txnama, txtelepon, txusername, txpassword;
    JButton save, back;
    
    public RegistrasiAdminView(){
        Image image = new ImageIcon(getClass().getResource("bg6.jpg")).getImage();
         this.setContentPane(new JPanel() {
         @Override
            public void paintComponent(Graphics g) {
               super.paintComponent(g);
               g.drawImage(image, 0, 0, 500, 450 , null);
            }
         }); 
        setTitle("Registrasi Admin");
        
        judul = new JLabel("REGISTRASI ADMIN BARU");
        id_admin = new JLabel("Id Admin");
        nama = new JLabel("Nama");
        telepon = new JLabel("Telepon");
        username = new JLabel("Username");
        password = new JLabel("Password");
        
        Font font = new Font("Tahoma", 1, 14);
        Font font1 = new Font("Cooper Black", 1, 26);
        id_admin.setFont(font);
        nama.setFont(font);
        username.setFont(font);
        password.setFont(font);
        judul.setFont(font1);
        telepon.setFont(font);
        
        id_admin.setForeground(Color.WHITE);
        nama.setForeground(Color.WHITE);
        password.setForeground(Color.WHITE);
        judul.setForeground(Color.WHITE);
        telepon.setForeground(Color.WHITE);
        username.setForeground(Color.WHITE);
        
        Random idRandom = new Random();
        int id = 1000000 + idRandom.nextInt( 9999999 );
        txid = new JTextField(Integer.toString(id));
        txnama = new JTextField();
        txtelepon = new JTextField();
        txusername = new JTextField();
        txpassword = new JTextField();
        
         txid.setEditable(false);
        
        save = new JButton("Save");
        back = new JButton("Back");
        
        setLayout(null);
        add(judul);
        add(id_admin);
        add(nama);
        add(telepon);
        add(username);
        add(password);
        add(txid);
        add(txnama);
        add(txtelepon);
        add(txusername);
        add(txpassword);
        add(save);
        add(back);
        
        judul.setBounds(50, 20, 450, 25);
        id_admin.setBounds(60, 90, 70, 30);
        txid.setBounds(150, 90, 260, 30);
        nama.setBounds(60, 135, 70, 30);
        txnama.setBounds(150, 135, 260, 30);
        telepon.setBounds(60, 180, 70, 30);
        txtelepon.setBounds(150, 180, 260, 30);
        username.setBounds(60, 225, 70, 30);
        txusername.setBounds(150, 225, 260, 30);
        password.setBounds(60, 270, 70, 30);
        txpassword.setBounds(150, 270, 260, 30);
        save.setBounds(140, 320, 100, 30);
        back.setBounds(250, 320, 100, 30);
        
        setSize(500,450);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    
    public String getIdAdmin(){
        return txid.getText();
    }
    
    public String getNama(){
        return txnama.getText();
    }
    
    public String getTelepon(){
        return txtelepon.getText();
    }
    
    public String getUsername(){
        return txusername.getText();
    }
    
    public String getPassword(){
        return txpassword.getText();
    }
}
