
package registrasiadmin;

import java.sql.*;
import javax.swing.JOptionPane;

public class RegistrasiAdminDAO {
    Connection koneksi;
    Statement statement;
    
    public RegistrasiAdminDAO(){
         try{
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost/perpustakaan";
            koneksi = DriverManager.getConnection(url, "root", "");
            statement = koneksi.createStatement();
        }catch(ClassNotFoundException ex){
            JOptionPane.showMessageDialog(null, "Class Not found : " + ex);
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "SQL Exception : " + ex);
        }
    }
    
    public void Insert(RegistrasiAdminModel Model){
        try{
            String query = "INSERT INTO admin VALUES ('"+Model.getIdAdmin()+"','"+
                    Model.getNama()+"','"+Model.getUsername()+"','"+
                    Model.getPassword()+"','"+Model.getTelepon()+"')";
            statement.executeUpdate(query);
            JOptionPane.showMessageDialog(null, "Data disimpan");
        }catch(Exception sql){
            JOptionPane.showMessageDialog(null, sql.getMessage());
        }
    }
}
