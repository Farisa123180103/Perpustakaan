
package registrasiadmin;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import menuadmin.MenuMVC;

public class RegistrasiAdminController {
    RegistrasiAdminModel model;
    RegistrasiAdminView view;
    RegistrasiAdminDAO dao;
    
    public RegistrasiAdminController(RegistrasiAdminModel model, RegistrasiAdminView view,
            RegistrasiAdminDAO dao){
        this.model = model;
        this.view = view;
        this.dao = dao;
        
        view.save.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
              String id_admin = view.getIdAdmin();
              String nama = view.getNama();
              String telepon = view.getTelepon();
              String username = view.getUsername();
              String password = view.getPassword();
              if(id_admin.isEmpty()||nama.isEmpty()||telepon.isEmpty()||username.isEmpty()
                      ||password.isEmpty()){
                  JOptionPane.showMessageDialog(null, "Harap isi semua field");
              }else{
                  model.setRegistrasiAdminModel(id_admin, nama, telepon, username, password);
                  dao.Insert(model);
                  view.txid.setText("");
                  view.txnama.setText("");
                  view.txtelepon.setText("");
                  view.txusername.setText("");
                  view.txpassword.setText("");
              }
            }
        });
        
        view.back.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                view.setVisible(false);
                new MenuMVC();
            }
        });
    }
    
}
