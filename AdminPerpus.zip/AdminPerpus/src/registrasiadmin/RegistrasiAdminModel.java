
package registrasiadmin;

public class RegistrasiAdminModel {
    private String id_admin, nama, telepon, username, password;
    
    public void setRegistrasiAdminModel(String nid_admin, String nnama,
            String ntelepon, String nusername, String npassword){
        this.id_admin = nid_admin;
        this.nama = nnama;
        this.telepon = ntelepon;
        this.username = nusername;
        this.password = npassword;
    }
    
    public String getIdAdmin(){
        return id_admin;
    }
    public void getIdAdmin(String id_admin){
        this.id_admin = id_admin;
    }
    public String getNama(){
        return nama;
    }
    public void getNama(String nama){
        this.nama = nama;
    }
    public String getTelepon(){
        return telepon;
    }
    public void getTelepon(String telepon){
        this.telepon = telepon;
    }
    public String getUsername(){
        return username;
    }
    public void getUsername(String username){
        this.username = username;
    }
    public String getPassword(){
        return password;
    }
    public void getPassword(String judul_buku){
        this.password = judul_buku;
    }
}
