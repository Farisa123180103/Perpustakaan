
package registrasiadmin;

public class RegistrasiAdminMVC {
    RegistrasiAdminView view = new RegistrasiAdminView();
    RegistrasiAdminModel model = new RegistrasiAdminModel();
    RegistrasiAdminDAO dao = new RegistrasiAdminDAO();
    RegistrasiAdminController controller = new RegistrasiAdminController(model, view, dao);
}
