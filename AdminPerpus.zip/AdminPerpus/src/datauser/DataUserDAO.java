
package datauser;

import java.sql.*;
import javax.swing.JOptionPane;

public class DataUserDAO {
    Connection koneksi;
    Statement statement;
    
    public DataUserDAO(){
         try{
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost/perpustakaan";
            koneksi = DriverManager.getConnection(url, "root", "");
            statement = koneksi.createStatement();
        }catch(ClassNotFoundException ex){
            JOptionPane.showMessageDialog(null, "Class Not found : " + ex);
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "SQL Exception : " + ex);
        }
    }
    
    public void Insert(DataUserModel Model){
        try{
            String query = "INSERT INTO user VALUES ('"+Model.getIdUser()+"','"+
                    Model.getNama()+"','"+Model.getUsername()+"','"+
                    Model.getPassword()+"','"+Model.getTelepon()+"')";
            statement.executeUpdate(query);
            JOptionPane.showMessageDialog(null, "Data disimpan");
        }catch(Exception sql){
            JOptionPane.showMessageDialog(null, sql.getMessage());
        }
    }
    
    public void Delete(DataUserModel Model){
        try{
            String query = "DELETE FROM user WHERE id_user='"+Model.getIdUser()+"'";
            statement.executeUpdate(query);
            JOptionPane.showMessageDialog(null, "Data berhasil di hapus");
        }catch(Exception sql){
            JOptionPane.showMessageDialog(null, sql.getMessage());
        }
    }
    
    public String[][] readData(){
        try{
            int jmlData = 0;
            String data[][] = new String[getJmldata()][8];
            String query = "SELECT * FROM user";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                data[jmlData][0] = resultSet.getString("id_user");
                data[jmlData][1] = resultSet.getString("nama_user");
                data[jmlData][2] = resultSet.getString("username");
                data[jmlData][3] = resultSet.getString("no_telepon");
                jmlData++;
            }
            return data;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return null;
        }
    }
    
    public String[][] Cari(DataUserModel Model){
        try{
            int jmlData = 0;
            String data[][] = new String[getJmldatacari(Model)][8];
            String query = "SELECT * FROM user WHERE nama_user LIKE '%"+
                    Model.getCari()+"%' OR id_user LIKE '%"+
                    Model.getCari()+"%' OR username LIKE '%"+
                    Model.getCari()+"%'";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                data[jmlData][0] = resultSet.getString("id_user");
                data[jmlData][1] = resultSet.getString("nama_user");
                data[jmlData][2] = resultSet.getString("username");
                data[jmlData][3] = resultSet.getString("no_telepon");
                jmlData++;
            }
            return data;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return null;
        }
    }
    
    public int getJmldata(){
        int jmlData = 0;
        try{
            String query = "SELECT * FROM user";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                jmlData++;
            }
             return jmlData;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return 0;
        }
    }
    
    public int getJmldatacari(DataUserModel Model){
        int jmlData = 0;
        try{
            String query = "SELECT * FROM user WHERE nama_user LIKE '%"+
                    Model.getCari()+"%' OR id_user LIKE '%"+
                    Model.getCari()+"%' OR username LIKE '%"+
                    Model.getCari()+"%'";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                jmlData++;
            }
             return jmlData;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return 0;
        }
    }

   
}
