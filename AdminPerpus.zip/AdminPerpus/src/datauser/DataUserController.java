
package datauser;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.*;
import menuadmin.MenuMVC;

public class DataUserController {
    DataUserModel model;
    DataUserView view;
    DataUserDAO dao;
    
    public DataUserController(DataUserModel model, DataUserView view, 
            DataUserDAO dao ){
        this.model = model;
        this.view = view;
        this.dao = dao;
        
        if (dao.getJmldata() != 0){
            String dataPeminjam[][] = dao.readData();
            view.tabel.setModel((new JTable(dataPeminjam, view.namaKolom)).getModel());
        }else{
            JOptionPane.showMessageDialog(null, "Data Tidak Ada");
        }
        
        view.input.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
              String id_user = view.getIdUser();
              String nama = view.getNama();
              String telepon = view.getTelepon();
              String username = view.getUsername();
              String password = view.getPassword();
              if(id_user.isEmpty()||nama.isEmpty()||telepon.isEmpty()||username.isEmpty()
                      ||password.isEmpty()){
                  JOptionPane.showMessageDialog(null, "Harap isi semua field");
              }else{
                  model.setDataUserModel(id_user, nama, telepon, username, password);
                  dao.Insert(model);
                  String dataPeminjam[][] = dao.readData();
                  view.tabel.setModel((new JTable(dataPeminjam, view.namaKolom)).getModel());
                  view.txid.setText("");
                  view.txnama.setText("");
                  view.txtelepon.setText("");
                  view.txusername.setText("");
                  view.txpassword.setText("");
              }
            }
        });
        
        view.tabel.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent me){
		int pilih = view.tabel.getSelectedRow();
                    if(pilih == -1)
                        {
                            return;
			}
                    else{
                        String id = (String) view.tabel.getValueAt(pilih, 0);
                        model.setIdUser(id);
                    }
            }
	});
        
        view.hapus.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                dao.Delete(model);
                String dataPeminjaman[][] = dao.readData();
                view.tabel.setModel((new JTable(dataPeminjaman, view.namaKolom)).getModel());
            }
        });
        
        view.cari.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
              String cari = view.getCari();
              model.setCari(cari);
              String dataPeminjaman[][] = dao.Cari(model);
              view.tabel.setModel((new JTable(dataPeminjaman, view.namaKolom)).getModel());
            }
        });
        
        view.back.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                view.setVisible(false);
                new MenuMVC();
            }
        });
        
        view.refresh.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
              view.txcari.setText("");
              String dataUser[][] = dao.readData();
              view.tabel.setModel((new JTable(dataUser, view.namaKolom)).getModel());
            }
        });
    }
}
