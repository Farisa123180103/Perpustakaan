
package datauser;

public class DataUserMVC {
    DataUserView view = new DataUserView();
    DataUserModel model = new DataUserModel();
    DataUserDAO dao = new DataUserDAO();
    DataUserController bukucontrol = new DataUserController(model, view, dao);
}
