
package datauser;


public class DataUserModel {
    private String cari, id_user, nama, telepon, username, password;
    
    public void setDataUserModel(String nid_user, String nnama,
            String ntelepon, String nusername, String npassword){
        this.id_user = nid_user;
        this.nama = nnama;
        this.telepon = ntelepon;
        this.username = nusername;
        this.password = npassword;
    }
    
     public String getNama(){
        return nama;
    }
    public void getNama(String nama){
        this.nama = nama;
    }
    public String getTelepon(){
        return telepon;
    }
    public void getTelepon(String telepon){
        this.telepon = telepon;
    }
    public String getUsername(){
        return username;
    }
    public void getUsername(String username){
        this.username = username;
    }
    public String getPassword(){
        return password;
    }
    public void getPassword(String judul_buku){
        this.password = judul_buku;
    }
    
    public void setCari(String ncari){
        this.cari = ncari;
    }
    public void setIdUser(String nid_user){
        this.id_user = nid_user;
    }
    
    public String getCari(){
        return cari;
    }
    public void getCari(String cari){
        this.cari = cari;
    }
    public String getIdUser(){
        return id_user;
    }
//    public void getIdUser(int id_peminjaman){
//        this.id_user = id_peminjaman;
//    }
}
