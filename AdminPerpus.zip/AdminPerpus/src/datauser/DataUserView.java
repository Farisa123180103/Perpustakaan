
package datauser;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.util.Random;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class DataUserView extends JFrame{
    JLabel judul, id_user, nama, telepon, username, password;
    JTextField txid, txnama, txtelepon, txusername, txpassword,txcari;
    JButton back, hapus, cari, refresh, input;
    JTable tabel;
    DefaultTableModel tableModel;
    JScrollPane scrollPane;
    Object namaKolom[] = {"ID Member","Username","Nama Member","Telepon"};
    
    public DataUserView(){
        Image image = new ImageIcon(getClass().getResource("bg6.jpg")).getImage();
         this.setContentPane(new JPanel() {
         @Override
            public void paintComponent(Graphics g) {
               super.paintComponent(g);
               g.drawImage(image, 0, 0, 1050, 505, null);
            }
         }); 
        setTitle("Data Member");
        
        tableModel = new DefaultTableModel(namaKolom, 0);
        tabel = new JTable(tableModel);
        scrollPane = new JScrollPane(tabel);
        
        judul = new JLabel("DATA MEMBER PERPUSTAKAAN");
        id_user = new JLabel("Id User");
        nama = new JLabel("Nama");
        telepon = new JLabel("Telepon");
        username = new JLabel("Username");
        password = new JLabel("Password");
        
        Font font = new Font("Tahoma", 1, 14);
        Font font1 = new Font("Cooper Black", 1, 26);
        id_user.setFont(font);
        nama.setFont(font);
        username.setFont(font);
        password.setFont(font);
        judul.setFont(font1);
        telepon.setFont(font);
        judul.setFont(font1);
        
        id_user.setForeground(Color.WHITE);
        nama.setForeground(Color.WHITE);
        password.setForeground(Color.WHITE);
        judul.setForeground(Color.WHITE);
        telepon.setForeground(Color.WHITE);
        username.setForeground(Color.WHITE);
        judul.setForeground(Color.WHITE);
        
        Random idRandom = new Random();
        int id = 1000000 + idRandom.nextInt( 9999999 );
        txid = new JTextField(Integer.toString(id));
        txnama = new JTextField();
        txtelepon = new JTextField();
        txusername = new JTextField();
        txpassword = new JTextField();
        txcari = new JTextField();
        
         txid.setEditable(false);
        
        input = new JButton("Save");
        cari= new JButton("Cari");
        hapus = new JButton("Hapus");
        back = new JButton("Back");
        refresh = new JButton("Refresh");
        
        setLayout(null);
        add(refresh);
        add(judul);
        add(txcari);
        add(cari);
        add(hapus);
        add(back);
        add(scrollPane);
        add(id_user);
        add(nama);
        add(telepon);
        add(username);
        add(password);
        add(txid);
        add(txnama);
        add(txtelepon);
        add(txusername);
        add(txpassword);
        add(input);
        
        judul.setBounds(150, 20, 500, 25);
        id_user.setBounds(20, 110, 80, 30);
        txid.setBounds(20, 140, 325, 30);
        nama.setBounds(20, 170, 150, 30);
        txnama.setBounds(20, 200, 325, 30);
        telepon.setBounds(20, 230, 150, 30);
        txtelepon.setBounds(20, 260, 325, 30);
        username.setBounds(20, 290, 100, 30);
        txusername.setBounds(20, 320, 325, 30);
        password.setBounds(20, 350, 100, 30);
        txpassword.setBounds(20, 380, 325, 30);
        back.setBounds(250, 425, 100, 30);
        txcari.setBounds(20, 60, 230, 30);
        cari.setBounds(260, 60, 84, 30);
        input.setBounds(370, 425, 85, 30);
        refresh.setBounds(465, 425, 85, 30);
        hapus.setBounds(560, 425, 85, 30);
        back.setBounds(883, 425, 85, 30);
        scrollPane.setBounds(370, 60, 645, 355);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        
        setSize(1050,505);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    
    public String getCari(){
        return txcari.getText();
    }
    
    public String getIdUser(){
        return txid.getText();
    }
    
    public String getNama(){
        return txnama.getText();
    }
    
    public String getTelepon(){
        return txtelepon.getText();
    }
    
    public String getUsername(){
        return txusername.getText();
    }
    
    public String getPassword(){
        return txpassword.getText();
    }
}
