
package inputbuku;

import java.sql.*;
import java.util.Random;
import javax.swing.JOptionPane;

public class InputBukuDAO {
    Connection koneksi;
    Statement statement;
    
    public InputBukuDAO(){
         try{
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost/perpustakaan";
            koneksi = DriverManager.getConnection(url, "root", "");
            statement = koneksi.createStatement();
        }catch(ClassNotFoundException ex){
            JOptionPane.showMessageDialog(null, "Class Not found : " + ex);
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "SQL Exception : " + ex);
        }
    }
    
    public void Insert(InputBukuModel Model){
        try{
            Random idRandom = new Random();
            int id_buku = 1000000 + idRandom.nextInt( 9999999 );
            String query = "INSERT INTO buku VALUES ('"+id_buku+"','"+Model.getJudulBuku()+
                    "','"+Model.getPengarang()+"','"+Model.getPenerbit()+
                    "','"+Model.getTahun()+"','"+Model.getGenre()+"','"+Model.getStok()+"')";
            statement.executeUpdate(query);
            JOptionPane.showMessageDialog(null, "Data disimpan");
        }catch(Exception sql){
            JOptionPane.showMessageDialog(null, sql.getMessage());
        }
    }
    
    public void Update(InputBukuModel Model){
        try{
            String query = "UPDATE buku SET judul_buku ='"+Model.getJudulBuku()+
                    "',pengarang='"+Model.getPengarang()+"',penerbit='"+Model.getPenerbit()+
                    "',tahun='"+Model.getTahun()+"',genre='"+Model.getGenre()+"',stok='"+Model.getStok()+
                    "' WHERE id_buku='"+Model.getIdBuku()+"'";
            statement.executeUpdate(query);
            JOptionPane.showMessageDialog(null, "Data berhasil di update");
        }catch(Exception sql){
            JOptionPane.showMessageDialog(null, sql.getMessage());
        }
    }
    
     public void Delete(InputBukuModel Model){
        try{
            String query = "DELETE FROM buku WHERE id_buku='"+Model.getIdBuku()+"'";
            statement.executeUpdate(query);
            JOptionPane.showMessageDialog(null, "Data berhasil di hapus");
        }catch(Exception sql){
            JOptionPane.showMessageDialog(null, sql.getMessage());
        }
    }
     
    public String[][] Cari(InputBukuModel Model){
        try{
            int Data = 0;
            String data[][] = new String[getJmldatacari(Model)][8];
            String query = "SELECT * FROM buku WHERE judul_buku LIKE '%"+Model.getCari()+"%'";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                data[Data][0] = resultSet.getString("id_buku");
                data[Data][1] = resultSet.getString("judul_buku");
                data[Data][2] = resultSet.getString("genre");
                data[Data][3] = resultSet.getString("pengarang");
                data[Data][4] = resultSet.getString("penerbit");
                data[Data][5] = resultSet.getString("tahun");
                data[Data][6] = resultSet.getString("stok");
                Data++;
            }
            return data;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return null;
        }
    }
    
    public String[][] readBuku(){
        try{
            int jmlData = 0;
            String data[][] = new String[getJmldata()][8];
            String query = "SELECT * FROM buku";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                data[jmlData][0] = resultSet.getString("id_buku");
                data[jmlData][1] = resultSet.getString("judul_buku");
                data[jmlData][2] = resultSet.getString("genre");
                data[jmlData][3] = resultSet.getString("pengarang");
                data[jmlData][4] = resultSet.getString("penerbit");
                data[jmlData][5] = resultSet.getString("tahun");
                data[jmlData][6] = resultSet.getString("stok");
                jmlData++;
            }
            return data;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return null;
        }
    }
    
    public int getJmldata(){
        int jmlData = 0;
        try{
            String query = "SELECT * FROM buku";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                jmlData++;
            }
             return jmlData;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return 0;
        }
    }
    
    public int getJmldatacari(InputBukuModel Model){
        int jmlData = 0;
        try{
            String query = "SELECT * FROM buku WHERE judul_buku LIKE '%"+Model.getCari()+"%'";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                jmlData++;
            }
             return jmlData;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return 0;
        }
    }
}
