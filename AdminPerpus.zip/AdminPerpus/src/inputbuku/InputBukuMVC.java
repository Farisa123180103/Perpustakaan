package inputbuku;


public class InputBukuMVC {
    InputBukuView bukuview = new InputBukuView();
    InputBukuModel bukumodel = new InputBukuModel();
    InputBukuDAO bukudao = new InputBukuDAO();
    InputBukuController bukucontrol = new InputBukuController(bukumodel, bukuview, bukudao);
}
