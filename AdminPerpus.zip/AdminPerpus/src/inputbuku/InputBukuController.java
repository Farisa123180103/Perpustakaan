package inputbuku;

import menuadmin.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.*;

public class InputBukuController {
    InputBukuModel modelbuku;
    InputBukuView viewbuku;
    InputBukuDAO daobuku;
    
    public InputBukuController(InputBukuModel modelbuku, InputBukuView viewbuku, InputBukuDAO daobuku){
        this.modelbuku = modelbuku;
        this.viewbuku = viewbuku;
        this.daobuku = daobuku;
        
        if (daobuku.getJmldata() != 0){
            String dataBuku[][] = daobuku.readBuku();
            viewbuku.tabel.setModel((new JTable(dataBuku, viewbuku.namaKolom)).getModel());
        }else{
            JOptionPane.showMessageDialog(null, "Data Tidak Ada");
        }
        
        viewbuku.input.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
              String judul_buku = viewbuku.getJudulBuku();
              String pengarang = viewbuku.getPengarang();
              String penerbit = viewbuku.getPenerbit();
              String tahun = viewbuku.getTahun();
              String genre = viewbuku.getGenre();
              String stok = viewbuku.getStok();
              if(judul_buku.isEmpty()||pengarang.isEmpty()||penerbit.isEmpty()||tahun.isEmpty()
                      ||genre.isEmpty()){
                  JOptionPane.showMessageDialog(null, "Harap isi semua field");
              }else{
                  modelbuku.setInputBukuModel(judul_buku, pengarang, penerbit, genre, tahun, stok);
                  daobuku.Insert(modelbuku);
                  String dataBuku[][] = daobuku.readBuku();
                  viewbuku.txjudul_buku.setText("");
                  viewbuku.txpengarang.setText("");
                  viewbuku.txpenerbit.setText("");
                  viewbuku.txtahun.setText("");
                  viewbuku.txgenre.setText("");
                  viewbuku.txstok.setText("");
                  viewbuku.tabel.setModel((new JTable(dataBuku, viewbuku.namaKolom)).getModel());
              }
            }
        });
        
        viewbuku.tabel.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent me){
		int pilih = viewbuku.tabel.getSelectedRow();
                    if(pilih == -1)
                        {
                            return;
			}
                    else{
                    String set = (String) viewbuku.tabel.getValueAt(pilih, 0);
                    int id = Integer.parseInt(set);
                    modelbuku.setIdBuku(id);
                    String judul_buku = (String) viewbuku.tabel.getValueAt(pilih, 1);
                    viewbuku.txjudul_buku.setText(judul_buku);
                    String genre = (String) viewbuku.tabel.getValueAt(pilih, 2);
                    viewbuku.txgenre.setText(genre);
                    String pengarang = (String) viewbuku.tabel.getValueAt(pilih, 3);
                    viewbuku.txpengarang.setText(pengarang);
                    String penerbit = (String) viewbuku.tabel.getValueAt(pilih, 4);
                    viewbuku.txpenerbit.setText(penerbit);
                    String tahun = (String) viewbuku.tabel.getValueAt(pilih, 5);
                    viewbuku.txtahun.setText(tahun);
                    String stok = (String) viewbuku.tabel.getValueAt(pilih, 6);
                    viewbuku.txstok.setText(stok);}
            }
	});
        
       viewbuku.update.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
              String judul_buku = viewbuku.getJudulBuku();
              String pengarang = viewbuku.getPengarang();
              String penerbit = viewbuku.getPenerbit();
              String tahun = viewbuku.getTahun();
              String genre = viewbuku.getGenre();
              String stok = viewbuku.getStok();
              if(judul_buku.isEmpty()||pengarang.isEmpty()||penerbit.isEmpty()||tahun.isEmpty()
                      ||genre.isEmpty()){
                  JOptionPane.showMessageDialog(null, "Harap isi semua field");
              }else{
                  modelbuku.setInputBukuModel(judul_buku, pengarang, penerbit, genre, tahun, stok);
                  daobuku.Update(modelbuku);
                  String dataBuku[][] = daobuku.readBuku();
                  viewbuku.txjudul_buku.setText("");
                  viewbuku.txpengarang.setText("");
                  viewbuku.txpenerbit.setText("");
                  viewbuku.txtahun.setText("");
                  viewbuku.txgenre.setText("");
                  viewbuku.txstok.setText("");
                  viewbuku.tabel.setModel((new JTable(dataBuku, viewbuku.namaKolom)).getModel());
              }
            }
        });
       
        viewbuku.delete.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
              String judul_buku = viewbuku.getJudulBuku();
              String pengarang = viewbuku.getPengarang();
              String penerbit = viewbuku.getPenerbit();
              String tahun = viewbuku.getTahun();
              String genre = viewbuku.getGenre();
              String stok = viewbuku.getStok();
              if(judul_buku.isEmpty()||pengarang.isEmpty()||penerbit.isEmpty()||tahun.isEmpty()
                      ||genre.isEmpty()){
                  JOptionPane.showMessageDialog(null, "Harap isi semua field");
              }else{
                  modelbuku.setInputBukuModel(judul_buku, pengarang, penerbit, genre, tahun, stok);
                  daobuku.Delete(modelbuku);
                  String dataBuku[][] = daobuku.readBuku();
                  viewbuku.txjudul_buku.setText("");
                  viewbuku.txpengarang.setText("");
                  viewbuku.txpenerbit.setText("");
                  viewbuku.txtahun.setText("");
                  viewbuku.txgenre.setText("");
                  viewbuku.txstok.setText("");
                  viewbuku.tabel.setModel((new JTable(dataBuku, viewbuku.namaKolom)).getModel());
              }
            }
        });
        
        viewbuku.cari.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
              String cari = viewbuku.getCari();
              modelbuku.setCari(cari);
              String dataBuku[][] = daobuku.Cari(modelbuku);
              viewbuku.txjudul_buku.setText("");
              viewbuku.txpengarang.setText("");
              viewbuku.txpenerbit.setText("");
              viewbuku.txtahun.setText("");
              viewbuku.txgenre.setText("");
              viewbuku.txstok.setText("");
              viewbuku.tabel.setModel((new JTable(dataBuku, viewbuku.namaKolom)).getModel());
            }
        });
        
        viewbuku.back.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                viewbuku.setVisible(false);
                new MenuMVC();
            }
        });
    }
}
