
package inputbuku;

public class InputBukuModel {
    private String judul_buku, pengarang, penerbit, genre, tahun, cari, stok;
    private int id_buku;
    
    public void setInputBukuModel(String njudul_buku, String npengarang,
            String npenerbit, String ngenre, String ntahun, String nstok){
        this.judul_buku = njudul_buku;
        this.pengarang = npengarang;
        this.penerbit = npenerbit;
        this.genre = ngenre;
        this.tahun = ntahun;
        this.stok = nstok;
    }
    public void setIdBuku(int nid_buku){
        this.id_buku = nid_buku;
    }
    public void setCari(String ncari){
        this.cari = ncari;
    }
    
    public String getJudulBuku(){
        return judul_buku;
    }
    public void getJudulBuku(String judul_buku){
        this.judul_buku = judul_buku;
    }
    public String getPengarang(){
        return pengarang;
    }
    public void getPengarang(String pengarang){
        this.pengarang = pengarang;
    }
    public String getPenerbit(){
        return penerbit;
    }
    public void getPenerbit(String penerbit){
        this.penerbit = penerbit;
    }
    public String getGenre(){
        return genre;
    }
    public void getGenre(String genre){
        this.genre = genre;
    }
    public String getTahun(){
        return tahun;
    }
    public void getTahun(String tahun){
        this.tahun = tahun;
    }
    public int getIdBuku(){
        return id_buku;
    }
    public void getIdBuku(int id_buku){
        this.id_buku = id_buku;
    }
    public String getCari(){
        return cari;
    }
    public void getCari(String cari){
        this.cari = cari;
    }
    public String getStok(){
        return stok;
    }
    public void getStok(String stok){
        this.stok = stok;
    }
}
