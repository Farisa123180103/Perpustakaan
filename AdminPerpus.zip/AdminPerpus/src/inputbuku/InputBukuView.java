package inputbuku;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class InputBukuView extends JFrame{
    JLabel judul, judul_buku, penerbit, pengarang, tahun, genre, stok;
    JTextField txjudul_buku, txpenerbit, txpengarang, txtahun, txgenre, txcari_buku, txstok;
    JButton cari, input, delete, update, back;
    JTable tabel;
    DefaultTableModel tableModel;
    JScrollPane scrollPane;
    Object namaKolom[] = {"ID","Judul Buku","Genre","Pengarang","Penerbit","Tahun Terbit","Stok"};
            
    public InputBukuView(){
        Image image = new ImageIcon(getClass().getResource("bg6.jpg")).getImage();
         this.setContentPane(new JPanel() {
         @Override
            public void paintComponent(Graphics g) {
               super.paintComponent(g);
               g.drawImage(image, 0, 0, 1100,510, null);
            }
         }); 
        setTitle("Pemrosesan Data Buku");
        
        tableModel = new DefaultTableModel(namaKolom, 0);
        tabel = new JTable(tableModel);
        scrollPane = new JScrollPane(tabel);
        
        judul = new JLabel("PEMROSESAN DATA BUKU");
        judul_buku = new JLabel("Judul Buku");
        pengarang = new JLabel("Nama Pengarang");
        penerbit = new JLabel("Penerbit");
        genre = new JLabel("Genre");
        tahun = new JLabel("Tahun Terbit");
        stok = new JLabel("Stok");
        
        Font font = new Font("Tahoma", 1, 14);
        Font font1 = new Font("Cooper Black", 1, 26);
        judul_buku.setFont(font);
        pengarang.setFont(font);
        penerbit.setFont(font);
        genre.setFont(font);
        tahun.setFont(font);
        judul.setFont(font1);
        stok.setFont(font);
        
        judul_buku.setForeground(Color.WHITE);
        judul.setForeground(Color.WHITE);
        pengarang.setForeground(Color.WHITE);
        penerbit.setForeground(Color.WHITE);
        genre.setForeground(Color.WHITE);
        tahun.setForeground(Color.WHITE);
        stok.setForeground(Color.WHITE);
        
        txcari_buku = new JTextField();
        txjudul_buku = new JTextField();
        txpengarang = new JTextField();
        txpenerbit = new JTextField();
        txgenre = new JTextField();
        txtahun = new JTextField();
        txstok = new JTextField();
        
        cari = new JButton("Search");
        input = new JButton("INPUT");
        update = new JButton("UPDATE");
        delete = new JButton("DELETE");
        back = new JButton("Back");
       
        setLayout(null);
        add(scrollPane);
        add(judul);
        add(judul_buku);
        add(pengarang);
        add(penerbit);
        add(genre);
        add(tahun);
        add(stok);
        add(txcari_buku);
        add(txjudul_buku);
        add(txpengarang);
        add(txpenerbit);
        add(txgenre);
        add(txtahun);
        add(txstok);
        add(cari);
        add(input);
        add(update);
        add(delete);
        add(back);
        
        judul.setBounds(320, 20, 400, 25);
        txcari_buku.setBounds(20, 60, 230, 30);
        cari.setBounds(260, 60, 84, 30);
        judul_buku.setBounds(20, 110, 80, 30);
        txjudul_buku.setBounds(20, 140, 325, 30);
        pengarang.setBounds(20, 170, 150, 30);
        txpengarang.setBounds(20, 200, 325, 30);
        penerbit.setBounds(20, 230, 150, 30);
        txpenerbit.setBounds(20, 260, 325, 30);
        genre.setBounds(20, 290, 100, 30);
        txgenre.setBounds(20, 320, 325, 30);
        tahun.setBounds(20, 350, 100, 30);
        txtahun.setBounds(20, 380, 152, 30);
        stok.setBounds(192, 350, 100, 30);
        txstok.setBounds(192, 380, 152, 30);
        input.setBounds(370, 425, 85, 30);
        update.setBounds(465, 425, 85, 30);
        delete.setBounds(560, 425, 85, 30);
        back.setBounds(983, 425, 85, 30);
        scrollPane.setBounds(370, 60, 700, 351);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        
        setSize(1100,510);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    
    public String getJudulBuku(){
        return txjudul_buku.getText();
    }
    
    public String getPengarang(){
        return txpengarang.getText();
    }
    
    public String getPenerbit(){
        return txpenerbit.getText();
    }
    
    public String getGenre(){
        return txgenre.getText();
    }
    
    public String getTahun(){
        return txtahun.getText();
    }
    
    public String getCari(){
        return txcari_buku.getText();
    }
    
    public String getStok(){
        return txstok.getText();
    }
}
