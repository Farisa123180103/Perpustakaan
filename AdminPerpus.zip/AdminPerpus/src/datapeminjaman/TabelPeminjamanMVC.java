
package datapeminjaman;

public class TabelPeminjamanMVC {
    TabelPeminjamanView view = new TabelPeminjamanView();
    TabelPeminjamanModel model = new TabelPeminjamanModel();
    TabelPeminjamanDAO dao = new TabelPeminjamanDAO();
    TabelPeminjamanController controller = new TabelPeminjamanController(model, view, dao);
    
}
