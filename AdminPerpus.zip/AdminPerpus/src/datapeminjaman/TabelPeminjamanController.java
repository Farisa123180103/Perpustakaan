
package datapeminjaman;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.*;
import peminjaman.*;

public class TabelPeminjamanController {
    TabelPeminjamanModel model;
    TabelPeminjamanView view;
    TabelPeminjamanDAO dao;
    
    public TabelPeminjamanController(TabelPeminjamanModel model, TabelPeminjamanView view, 
            TabelPeminjamanDAO dao ){
        this.model = model;
        this.view = view;
        this.dao = dao;
        
        if (dao.getJmldata() != 0){
            String dataPeminjam[][] = dao.readData();
            view.tabel.setModel((new JTable(dataPeminjam, view.namaKolom)).getModel());
        }else{
            JOptionPane.showMessageDialog(null, "Data Tidak Ada");
        }
        
        view.tabel.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent me){
		int pilih = view.tabel.getSelectedRow();
                    if(pilih == -1)
                        {
                            return;
			}
                    else{
                        String set = (String) view.tabel.getValueAt(pilih, 0);
                        int id = Integer.parseInt(set);
                        model.setIdPeminjaman(id);
                    }
            }
	});
        
        view.hapus.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                dao.Delete(model);
                String dataPeminjaman[][] = dao.readData();
                view.tabel.setModel((new JTable(dataPeminjaman, view.namaKolom)).getModel());
            }
        });
        
        view.cariTabel.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
              String cari = view.getCariTabel();
              model.setCari(cari);
              String dataPeminjaman[][] = dao.Cari(model);
              view.tabel.setModel((new JTable(dataPeminjaman, view.namaKolom)).getModel());
            }
        });
        
        view.back.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                view.setVisible(false);
            }
        });
        
        view.refresh.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
              view.txcariTabel.setText("");
              String dataPeminjam[][] = dao.readData();
              view.tabel.setModel((new JTable(dataPeminjam, view.namaKolom)).getModel());
            }
        });
    }
}
