
package datapeminjaman;

import java.sql.*;
import javax.swing.JOptionPane;

public class TabelPeminjamanDAO {
    Connection koneksi;
    Statement statement;
    
    public TabelPeminjamanDAO(){
         try{
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost/perpustakaan";
            koneksi = DriverManager.getConnection(url, "root", "");
            statement = koneksi.createStatement();
        }catch(ClassNotFoundException ex){
            JOptionPane.showMessageDialog(null, "Class Not found : " + ex);
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "SQL Exception : " + ex);
        }
    }
    
    public void Delete(TabelPeminjamanModel Model){
        try{
            String query = "DELETE FROM peminjaman_buku WHERE id_peminjaman='"+Model.getIdPeminjaman()+"'";
            String id = "SELECT * FROM peminjaman_buku WHERE id_peminjaman='"+Model.getIdPeminjaman()+
                    "' AND status = 'Dipinjam'";
            ResultSet resultSet = statement.executeQuery(id);
            if (resultSet.next()){
                String id_buku = resultSet.getString("id_buku").toString();
                String buku = "SELECT * FROM buku WHERE id_buku = "+id_buku;
                ResultSet rs = statement.executeQuery(buku);
                if (rs.next()){
                    int q = rs.getInt("stok");
                    int sb = q+1;
                    String stok = "UPDATE buku SET stok = "+sb+" WHERE id_buku="+id_buku;
                    statement.executeUpdate(stok);
                }
            }
            statement.executeUpdate(query);
            JOptionPane.showMessageDialog(null, "Data berhasil di hapus");
        }catch(Exception sql){
            JOptionPane.showMessageDialog(null, sql.getMessage());
        }
    }
    
    public String[][] readData(){
        try{
            int jmlData = 0;
            String data[][] = new String[getJmldata()][8];
            String query = "SELECT * FROM peminjaman_buku";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                data[jmlData][0] = resultSet.getString("id_peminjaman");
                data[jmlData][1] = resultSet.getString("judul_buku");
                data[jmlData][2] = resultSet.getString("pengarang");
                data[jmlData][3] = resultSet.getString("nama_user");
                data[jmlData][4] = resultSet.getString("no_telepon");
                data[jmlData][5] = resultSet.getString("status");
                jmlData++;
            }
            return data;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return null;
        }
    }
    
    public String[][] Cari(TabelPeminjamanModel Model){
        try{
            int jmlData = 0;
            String data[][] = new String[getJmldatacari(Model)][8];
            String query = "SELECT * FROM peminjaman_buku WHERE judul_buku LIKE '%"+
                    Model.getCari()+"%' OR id_peminjaman LIKE '%"+
                    Model.getCari()+"%' OR nama_user LIKE '%"+
                    Model.getCari()+"%'";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                data[jmlData][0] = resultSet.getString("id_peminjaman");
                data[jmlData][1] = resultSet.getString("judul_buku");
                data[jmlData][2] = resultSet.getString("pengarang");
                data[jmlData][3] = resultSet.getString("nama_user");
                data[jmlData][4] = resultSet.getString("no_telepon");
                data[jmlData][5] = resultSet.getString("status");
                jmlData++;
            }
            return data;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return null;
        }
    }
    
    public int getJmldata(){
        int jmlData = 0;
        try{
            String query = "SELECT * FROM peminjaman_buku";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                jmlData++;
            }
             return jmlData;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return 0;
        }
    }
    
    public int getJmldatacari(TabelPeminjamanModel Model){
        int jmlData = 0;
        try{
            String query = "SELECT * FROM peminjaman_buku WHERE judul_buku LIKE '%"+
                    Model.getCari()+"%' OR id_peminjaman LIKE '%"+
                    Model.getCari()+"%' OR nama_user LIKE '%"+
                    Model.getCari()+"%'";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                jmlData++;
            }
             return jmlData;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return 0;
        }
    }
}
