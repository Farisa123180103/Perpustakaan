
package datapeminjaman;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class TabelPeminjamanView extends JFrame{
    
    JLabel judul;
    JButton back, hapus, cariTabel, refresh;
    JTextField txcariTabel;
    JTable tabel;
    DefaultTableModel tableModel;
    JScrollPane scrollPane;
    Object namaKolom[] = {"ID Peminjamman","Judul Buku","Pengarang","Nama Peminjam","Telepon","Status"};
    
    public TabelPeminjamanView(){
         Image image = new ImageIcon(getClass().getResource("bg6.jpg")).getImage();
         this.setContentPane(new JPanel() {
         @Override
            public void paintComponent(Graphics g) {
               super.paintComponent(g);
               g.drawImage(image, 0, 0, 700,500, null);
            }
         }); 
        setTitle("Tabel Data Peminjaman Buku");
        
        tableModel = new DefaultTableModel(namaKolom, 0);
        tabel = new JTable(tableModel);
        scrollPane = new JScrollPane(tabel);
        
        judul = new JLabel("TABEL DATA PEMINJAMAN BUKU");
        
        Font font1 = new Font("Cooper Black", 1, 26);
        judul.setFont(font1);
        judul.setForeground(Color.WHITE);
        
        txcariTabel = new JTextField();
        
        cariTabel= new JButton("Cari");
        hapus = new JButton("Hapus");
        back = new JButton("Back");
        refresh = new JButton("Refresh");
        
        setLayout(null);
        add(refresh);
        add(judul);
        add(txcariTabel);
        add(cariTabel);
        add(hapus);
        add(back);
        add(scrollPane);
        
        judul.setBounds(70, 20, 550, 25);
        txcariTabel.setBounds(245, 65, 210, 30);
        cariTabel.setBounds(460, 65, 100, 30);
        refresh.setBounds(565, 65, 100, 30);
        hapus.setBounds(240, 400, 100, 30);
        back.setBounds(350, 400, 100, 30);
        scrollPane.setBounds(20, 100, 645, 280);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        
        setSize(700,500);
        setVisible(true);
        setDefaultCloseOperation(HIDE_ON_CLOSE);
    }
    
    public String getCariTabel(){
        return txcariTabel.getText();
    }
}
