
package datapeminjaman;

public class TabelPeminjamanModel {
    private String cari;
    private int id_peminjaman;
     
    public void setCari(String ncari){
        this.cari = ncari;
    }
    public void setIdPeminjaman(int nid_peminjaman){
        this.id_peminjaman = nid_peminjaman;
    }
     
    public String getCari(){
        return cari;
    }
    public void getCari(String cari){
        this.cari = cari;
    }
    public int getIdPeminjaman(){
        return id_peminjaman;
    }
    public void getIdPeminjaman(int id_peminjaman){
        this.id_peminjaman = id_peminjaman;
    }
}
