
package menuadmin;

import Login.LoginAdminMVC;
import datauser.DataUserMVC;
import inputbuku.*;
import peminjaman.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import pengembalian.PengembalianMVC;
import registrasiadmin.RegistrasiAdminMVC;

public class MenuController {
    MenuView menuview;
    
    public MenuController(MenuView menuview){
        this.menuview = menuview;
        
        menuview.input_buku.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                menuview.setVisible(false);
                new InputBukuMVC();
            }
        });
        
        menuview.input_pinjam.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                menuview.setVisible(false);
                new PeminjamanMVC();
            }
        });
        
        menuview.input_kembali.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                menuview.setVisible(false);
                new PengembalianMVC();
            }
        });
        
        menuview.lihat_user.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                menuview.setVisible(false);
                new DataUserMVC();
            }
        });
        
        menuview.input_admin.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                menuview.setVisible(false);
                new RegistrasiAdminMVC();
            }
        });
        
        menuview.keluar.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                menuview.setVisible(false);
                new LoginAdminMVC();
            }
        });
    }
}
