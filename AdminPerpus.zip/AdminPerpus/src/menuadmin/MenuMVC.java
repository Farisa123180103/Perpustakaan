
package menuadmin;

public class MenuMVC {
    MenuView view = new MenuView();
    MenuController controller = new MenuController(view);
}
