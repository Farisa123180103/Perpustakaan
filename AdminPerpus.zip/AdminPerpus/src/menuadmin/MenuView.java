package menuadmin;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.*;

public class MenuView extends JFrame{
    JLabel judul;
    JButton input_buku, input_pinjam, input_kembali, lihat_user, input_admin, keluar;
    
    public MenuView(){
        Image image = new ImageIcon(getClass().getResource("login user.jpg")).getImage();
         this.setContentPane(new JPanel() {
         @Override
            public void paintComponent(Graphics g) {
               super.paintComponent(g);
               g.drawImage(image, 0, 0, 450,380, null);
            }
         }); 
        setTitle("Menu Admin");
        
        judul = new JLabel("MENU ADMIN");
        
        input_buku = new JButton("Data Buku");
        input_pinjam = new JButton("Data Peminjaman Buku");
        input_kembali = new JButton("Data Pengembalian Buku");
        lihat_user = new JButton("Data Member");
        input_admin = new JButton("Data Admin");
        keluar = new JButton("Logout");
        
        Font font = new Font("Tahoma", 1, 26);
        Font font1 = new Font("Tahoma", 1, 36);
//        judul1.setFont(font);
        judul.setFont(font1);
//        judul.setForeground(Color.GRAY);
        
        setLayout(null);
        add(judul);
        add(input_buku);
        add(input_pinjam);
        add(input_kembali);
        add(lihat_user);
        add(input_admin);
        add(keluar);
        
        judul.setBounds(90, 20, 300, 25);
        input_buku.setBounds(70, 70, 290, 30);
        input_pinjam.setBounds(70, 110, 290, 30);
        input_kembali.setBounds(70, 150, 290, 30);
        lihat_user.setBounds(70, 190, 290, 30);
        input_admin.setBounds(70, 230, 290, 30);
        keluar.setBounds(70, 270, 290, 30);
        
        setSize(450,380);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
}
