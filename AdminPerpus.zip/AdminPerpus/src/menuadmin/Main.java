
package menuadmin;

import MenuLogin.MenuLoginMVC;

public class Main {
    public static void main(String[] args){
        MenuLoginMVC m = new MenuLoginMVC();
    }

   
}
