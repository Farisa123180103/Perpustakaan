/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MenuLogin;

import Login.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author HP
 */
public class MenuLoginController {
    MenuLoginView menuloginview;
    
    public MenuLoginController(MenuLoginView menuloginview){
        this.menuloginview = menuloginview;
        
        menuloginview.admin.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                menuloginview.setVisible(false);
                new LoginAdminMVC();
            }
        });
        
        menuloginview.user.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                menuloginview.setVisible(false);
                new LoginUserMVC();
            }
        });
    }
}
