/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MenuLogin;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author HP
 */
public class MenuLoginView extends JFrame{
    private Image image;
    JLabel judul1,judul2;
    JButton admin, user;
    
    public MenuLoginView(){
        image = new ImageIcon(getClass().getResource("menu awal.jpg")).getImage();
         this.setContentPane(new JPanel() {
         @Override
            public void paintComponent(Graphics g) {
               super.paintComponent(g);
               g.drawImage(image, 0, 0, 550, 400, null);
            }
         }); 
        setTitle("Menu Login");
        
//        judul1.setFont(new java.awt.Font("Tahoma", 1, 24));
//        judul2.setFont(new java.awt.Font("Times Roman", 1, 50));
        judul1 = new JLabel("WELLCOME!! ");
        judul2 = new JLabel("UPN LIBRARY");
        
        admin = new JButton("ADMIN");
        user = new JButton("USER");
        
        Font font = new Font("Forte", 1, 26);
        Font font1 = new Font("Tahoma", 1, 36);
        judul1.setFont(font);
        judul2.setFont(font1);
        
        judul1.setForeground(Color.WHITE);
        judul2.setForeground(Color.WHITE);
        
        setLayout(null);
        add(judul1);
        add(judul2);
        add(admin);
        add(user);
        
        judul1.setBounds(170, 30, 300, 50);
        judul2.setBounds(120, 90, 300, 25);
        admin.setBounds(200, 150, 100, 60);
        user.setBounds(200, 220, 100, 60);
        
        setSize(550,400);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
}

