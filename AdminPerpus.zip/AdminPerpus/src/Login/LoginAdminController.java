/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Login;

import MenuLogin.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import menuadmin.MenuMVC;

/**
 *
 * @author HP
 */
public class LoginAdminController {
    LoginAdminView loginadminview;
    private Connection koneksi;
    private Statement statement;
    
    public LoginAdminController(LoginAdminView loginadminview){
        this.loginadminview = loginadminview;
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost/perpustakaan";
            koneksi = DriverManager.getConnection(url, "root", "");
            statement = koneksi.createStatement();
        } catch (ClassNotFoundException ex){
            JOptionPane.showMessageDialog(null, "Class Not Found : " + ex);
        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null, "SQL Exception : " + ex);
        }
        
        loginadminview.login.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                String uname = loginadminview.getUname();
                String pw = loginadminview.getPw();
                
                try {
                String query = "SELECT * FROM admin WHERE username = '"+uname+
                    "' and password = '"+pw+"'";
                    ResultSet resultSet = statement.executeQuery(query);
                    if(uname.isEmpty() || pw.isEmpty()){
                    JOptionPane.showMessageDialog(null, "Adminname atau Password kosong");
                    } else if (resultSet.next()){
                        loginadminview.setVisible(false);
                        JOptionPane.showMessageDialog(null, "Login Berhasil");
                        new MenuMVC();
                    } else {
                        JOptionPane.showMessageDialog(null, "Adminname atau Password salah");
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(LoginAdminController.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            }
        });
        
        loginadminview.back.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                loginadminview.setVisible(false);
                new MenuLoginMVC();
            }
        });
    }
}
