/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Login;

/**
 *
 * @author HP
 */
public class LoginUserMVC {
    LoginUserView loginview = new LoginUserView();
    LoginUserController logincontroller = new LoginUserController(loginview);
}
