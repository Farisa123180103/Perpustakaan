/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Login;


import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.*;

/**
 *
 * @author HP
 */
public class LoginUserView extends JFrame{
    JLabel ljudul1,luser,lpass,lregis;
    JTextField txuname;
    JPasswordField pfpw;
    JButton back, login, regis;
    
    public LoginUserView(){
        Image image = new ImageIcon(getClass().getResource("bg2.jpg")).getImage();
         this.setContentPane(new JPanel() {
         @Override
            public void paintComponent(Graphics g) {
               super.paintComponent(g);
               g.drawImage(image, 0, 0, 550, 400, null);
            }
         });  
        setTitle("Login User");
        
//        ljudul1.setFont(new java.awt.Font("Tahoma", 1, 24));
//        judul2.setFont(new java.awt.Font("Times Roman", 1, 50));
        ljudul1 = new JLabel("UPN LIBRARY ");
        luser = new JLabel("Username");
        lpass = new JLabel("Passwoard");
        lregis = new JLabel("Belum Punya Akun?");
        
        txuname = new JTextField();
        pfpw = new JPasswordField();
        
        back = new JButton("Kembali");
        login = new JButton("Login");
        regis = new JButton("Buat Akun");
        
        Font font = new Font("Tahoma", 1, 14);
        Font font1 = new Font("Tahoma", 1, 36);
        luser.setFont(font);
        lpass.setFont(font);
        ljudul1.setFont(font1);
        lregis.setFont(font);
//        lregis.setForeground(Color.white);
//        luser.setForeground(Color.white);
//        lpass.setForeground(Color.WHITE);
//        ljudul1.setForeground(Color.BLACK);
        
        setLayout(null);
        add(ljudul1);
        add(luser);
        add(lpass);
        add(txuname);
        add(pfpw);
        add(back);
        add(login);
        add(lregis);
        add(regis);
        
        ljudul1.setBounds(130, 30, 300, 50);
        luser.setBounds(100, 100, 100, 25);
        lpass.setBounds(100, 150, 100, 25);
        txuname.setBounds(210, 100, 200, 30);
        pfpw.setBounds(210, 150, 200, 30);
        back.setBounds(120, 200, 90, 30);
        login.setBounds(280, 200, 90, 30);
        lregis.setBounds(180, 240, 150, 25);
        regis.setBounds(200, 280, 100, 30);
        
        setSize(550,400);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    
     public String getUname(){
        return txuname.getText();
    }
    
    public String getPw(){
         String pass = new String(pfpw.getPassword());
         return pass;
//        return pw.getPassword().toString();
    }
}

