/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Login;

import MenuLogin.MenuLoginMVC;
import Register.RegisMVC;
import User.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class LoginUserController {
    
    LoginUserView loginuserview;
    private Connection koneksi;
    private Statement statement;
    
    public LoginUserController(LoginUserView loginuserview){
        this.loginuserview = loginuserview;
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost/perpustakaan";
            koneksi = DriverManager.getConnection(url, "root", "");
            statement = koneksi.createStatement();
        } catch (ClassNotFoundException ex){
            JOptionPane.showMessageDialog(null, "Class Not Found : " + ex);
        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null, "SQL Exception : " + ex);
        }
        
        loginuserview.login.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                String uname = loginuserview.getUname();
                String pw = loginuserview.getPw();
                
                try {
                String query = "SELECT * FROM user WHERE username = '"+uname+
                    "' and password = '"+pw+"'";
                    ResultSet resultSet = statement.executeQuery(query);
                    if(uname.isEmpty() || pw.isEmpty()){
                    JOptionPane.showMessageDialog(null, "Username atau Password kosong");
                    } else if (resultSet.next()){
                        String u = resultSet.getString("nama_user");
                        int id = resultSet.getInt("id_user");
                        loginuserview.setVisible(false);
                        JOptionPane.showMessageDialog(null, "Login Berhasil");
                        DashboardView view = new DashboardView(u);
                        DashboardController controller = new DashboardController(view, u, id);
                    } else {
                        JOptionPane.showMessageDialog(null, "Username atau Password salah");
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(LoginUserController.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            }
        });
        
         loginuserview.regis.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                loginuserview.setVisible(false);
                new RegisMVC();
            }
        });
         
         loginuserview.back.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                loginuserview.setVisible(false);
                new MenuLoginMVC();
            }
        });
    }
}
