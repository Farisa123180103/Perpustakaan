
package pengembalian;

import java.sql.*;
import javax.swing.JOptionPane;

public class PengembalianDAO {
    Connection koneksi;
    Statement statement;
    
    public PengembalianDAO(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost/perpustakaan";
            koneksi = DriverManager.getConnection(url, "root", "");
            statement = koneksi.createStatement();
        }catch(ClassNotFoundException ex){
            JOptionPane.showMessageDialog(null, "Class Not found : " + ex);
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "SQL Exception : " + ex);
        }
    }
    
    public void Update(PengembalianModel Model){
        try{
            String status = "Dikembalikan";
            String query = "UPDATE peminjaman_buku SET status ='"+status+
                    "' WHERE id_peminjaman='"+Model.getIdPeminjaman()+"'";
            String id = "SELECT * FROM peminjaman_buku WHERE id_peminjaman='"+Model.getIdPeminjaman()+"'";
            ResultSet resultSet = statement.executeQuery(id);
            if (resultSet.next()){
                String id_buku = resultSet.getString("id_buku").toString();
                String buku = "SELECT * FROM buku WHERE id_buku = "+id_buku;
                ResultSet rs = statement.executeQuery(buku);
                if (rs.next()){
                    int q = rs.getInt("stok");
                    int sb = q+1;
                    String stok = "UPDATE buku SET stok = "+sb+" WHERE id_buku="+id_buku;
                    statement.executeUpdate(stok);
                }
            }
            statement.executeUpdate(query);
            JOptionPane.showMessageDialog(null, " Validasi berhasil");
        }catch(Exception sql){
            JOptionPane.showMessageDialog(null, sql.getMessage());
        }
    }
    
    public String[][] readPinjam(){
        try{
            int jmlData = 0;
            String data[][] = new String[getJmldataPinjam()][8];
            String query = "SELECT * FROM peminjaman_buku WHERE status = 'Dipinjam'";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                data[jmlData][0] = resultSet.getString("id_peminjaman");
                data[jmlData][1] = resultSet.getString("judul_buku");
                data[jmlData][2] = resultSet.getString("pengarang");
                data[jmlData][3] = resultSet.getString("nama_user");
                data[jmlData][4] = resultSet.getString("no_telepon");
                data[jmlData][5] = resultSet.getString("status");
                jmlData++;
            }
            return data;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return null;
        }
    }
    
    public String[][] readKembali(){
        try{
            int jmlData = 0;
            String data[][] = new String[getJmldataKembali()][8];
            String query = "SELECT * FROM peminjaman_buku WHERE status = 'Dikembalikan'";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                data[jmlData][0] = resultSet.getString("id_peminjaman");
                data[jmlData][1] = resultSet.getString("judul_buku");
                data[jmlData][2] = resultSet.getString("pengarang");
                data[jmlData][3] = resultSet.getString("nama_user");
                data[jmlData][4] = resultSet.getString("no_telepon");
                data[jmlData][5] = resultSet.getString("status");
                jmlData++;
            }
            return data;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return null;
        }
    }
    
    public int getJmldataPinjam(){
        int jmlData = 0;
        try{
            String query = "SELECT * FROM peminjaman_buku WHERE status = 'Dipinjam'";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                jmlData++;
            }
             return jmlData;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return 0;
        }
    }
    
    public int getJmldataKembali(){
        int jmlData = 0;
        try{
            String query = "SELECT * FROM peminjaman_buku WHERE status = 'Dikembalikan'";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                jmlData++;
            }
             return jmlData;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return 0;
        }
    }
    
    public String[][] CariPinjam(PengembalianModel Model){
        try{
            int jmlData = 0;
            String data[][] = new String[getJmldatacariPinjam(Model)][8];
            String query = "SELECT * FROM peminjaman_buku WHERE status = 'Dipinjam' AND (judul_buku LIKE '%"+
                    Model.getCari()+"%' OR id_peminjaman LIKE '%"+
                    Model.getCari()+"%' OR nama_user LIKE '%"+
                    Model.getCari()+"%')";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                data[jmlData][0] = resultSet.getString("id_peminjaman");
                data[jmlData][1] = resultSet.getString("judul_buku");
                data[jmlData][2] = resultSet.getString("pengarang");
                data[jmlData][3] = resultSet.getString("nama_user");
                data[jmlData][4] = resultSet.getString("no_telepon");
                data[jmlData][5] = resultSet.getString("status");
                jmlData++;
            }
            return data;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return null;
        }
    }
    
     public String[][] CariKembali(PengembalianModel Model){
        try{
            int jmlData = 0;
            String data[][] = new String[getJmldatacariKembali(Model)][8];
            String query = "SELECT * FROM peminjaman_buku WHERE status = 'Dikembalikan' AND (judul_buku LIKE '%"+
                    Model.getCari()+"%' OR id_peminjaman LIKE '%"+
                    Model.getCari()+"%' OR nama_user LIKE '%"+
                    Model.getCari()+"%')";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                data[jmlData][0] = resultSet.getString("id_peminjaman");
                data[jmlData][1] = resultSet.getString("judul_buku");
                data[jmlData][2] = resultSet.getString("pengarang");
                data[jmlData][3] = resultSet.getString("nama_user");
                data[jmlData][4] = resultSet.getString("no_telepon");
                data[jmlData][5] = resultSet.getString("status");
                jmlData++;
            }
            return data;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return null;
        }
    }
    
    public int getJmldatacariPinjam(PengembalianModel Model){
        int jmlData = 0;
        try{
            String query = "SELECT * FROM peminjaman_buku WHERE status = 'Dipinjam' AND (judul_buku LIKE '%"+
                    Model.getCari()+"%' OR id_peminjaman LIKE '%"+
                    Model.getCari()+"%' OR nama_user LIKE '%"+
                    Model.getCari()+"%')";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                jmlData++;
            }
             return jmlData;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return 0;
        }
    }
    
    public int getJmldatacariKembali(PengembalianModel Model){
        int jmlData = 0;
        try{
            String query = "SELECT * FROM peminjaman_buku WHERE status = 'Dikembalikan' AND (judul_buku LIKE '%"+
                    Model.getCari()+"%' OR id_peminjaman LIKE '%"+
                    Model.getCari()+"%' OR nama_user LIKE '%"+
                    Model.getCari()+"%')";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                jmlData++;
            }
             return jmlData;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return 0;
        }
    }
}
