
package pengembalian;

public class PengembalianMVC {
    PengembalianView view = new PengembalianView();
    PengembalianModel model = new PengembalianModel();
    PengembalianDAO dao = new PengembalianDAO();
    PengembalianController bukucontrol = new PengembalianController(model, view, dao);
}
