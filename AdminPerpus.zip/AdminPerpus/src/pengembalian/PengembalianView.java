
package pengembalian;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class PengembalianView extends JFrame{
    JLabel judul, info_pengembalian, id_peminjaman, judul_buku, pengarang, nama_user, telepon;
    JTextField txid, txjudul, txpengarang, txnama, txtelepon, txcari;
    JButton pengembalian, back, cariPinjam, cariKembali, cariRefresh, clear;
    JTable tabelPinjam, tabelKembali;
    DefaultTableModel tableModelPinjam, tableModelKembali;
    JScrollPane scrollPanePinjam, scrollPaneKembali;
    Object namaKolomPinjam[] = {"ID Peminjaman","Judul Buku","Pengarang","Nama Peminjam","Telepon","Status"};
    Object namaKolomKembali[] = {"ID Peminjaman","Judul Buku","Pengarang","Nama Peminjam","Telepon","Status"};
    
    public PengembalianView(){
        Image image = new ImageIcon(getClass().getResource("bg6.jpg")).getImage();
         this.setContentPane(new JPanel() {
         @Override
            public void paintComponent(Graphics g) {
               super.paintComponent(g);
               g.drawImage(image, 0, 0, 1100,680, null);
            }
         }); 
        setTitle("Pemrosesan Data Pengembalian Buku");
        
        tableModelPinjam = new DefaultTableModel(namaKolomPinjam, 0);
        tabelPinjam = new JTable(tableModelPinjam);
        scrollPanePinjam = new JScrollPane(tabelPinjam);
        tableModelKembali = new DefaultTableModel(namaKolomKembali, 0);
        tabelKembali = new JTable(tableModelKembali);
        scrollPaneKembali = new JScrollPane(tabelKembali);
        
        judul = new JLabel("PEMROSESAN DATA PENGEMBALIAN BUKU");
        info_pengembalian = new JLabel("----- Data Peminjaman -----");
        id_peminjaman = new JLabel("ID Peminjaman");
        judul_buku = new JLabel("Judul Buku");
        pengarang = new JLabel("Pengarang");
        nama_user = new JLabel("Nama");
        telepon = new JLabel("Telepon");
        
        Font font = new Font("Tahoma", 1, 14);
        Font font1 = new Font("Cooper Black", 1, 26);
        Font font2 = new Font("Comic Sans MS", 1, 16);
        judul_buku.setFont(font);
        info_pengembalian.setFont(font2);
        pengarang.setFont(font);
        judul.setFont(font1);
        nama_user.setFont(font);
        telepon.setFont(font);
        
        judul_buku.setForeground(Color.WHITE);
        info_pengembalian.setForeground(Color.WHITE);
        pengarang.setForeground(Color.WHITE);
        judul.setForeground(Color.WHITE);
        nama_user.setForeground(Color.WHITE);
        telepon.setForeground(Color.WHITE);
        
        txcari = new JTextField();
        txid = new JTextField();
        txjudul = new JTextField();
        txpengarang = new JTextField();
        txnama = new JTextField();
        txtelepon = new JTextField();
        
        txid.setEditable(false);
        txjudul.setEditable(false);
        txpengarang.setEditable(false);
        txnama.setEditable(false);
        txtelepon.setEditable(false);
        
        cariRefresh = new JButton("Refresh Pencarian");
        cariPinjam = new JButton("Cari Peminjaman");
        cariKembali = new JButton("Cari Pengembalian");
        back = new JButton("Back");
        clear = new JButton("Clear");
        pengembalian = new JButton("Validasi Pengembalian");
        
        setLayout(null);
        add(scrollPanePinjam);
        add(scrollPaneKembali);
        add(judul);
        add(info_pengembalian);
        add(id_peminjaman);
        add(judul_buku);
        add(pengarang);
        add(nama_user);
        add(telepon);
        add(txcari);
        add(txid);
        add(txjudul);
        add(txpengarang);
        add(txnama);
        add(txtelepon);
        add(cariRefresh);
        add(cariPinjam);
        add(cariKembali);
        add(back);
        add(clear);
        add(pengembalian);
        
        judul.setBounds(230, 20, 800, 25);
        txcari.setBounds(365, 80, 230, 30);
        cariPinjam.setBounds(605, 80, 150, 30);
        cariKembali.setBounds(760, 80, 150, 30);
        cariRefresh.setBounds(915, 80, 150, 30);
        info_pengembalian.setBounds(70, 125, 250, 30);
        id_peminjaman.setBounds(20, 170, 90, 30);
        txid.setBounds(120, 170, 220, 30);
        judul_buku.setBounds(20, 210, 90, 30);
        txjudul.setBounds(120, 210, 220, 30);
        pengarang.setBounds(20, 250, 90, 30);
        txpengarang.setBounds(120, 250, 220, 30);
        nama_user.setBounds(20, 290, 90, 30);
        txnama.setBounds(120, 290, 220, 30);
        telepon.setBounds(20, 330, 90, 30);
        txtelepon.setBounds(120, 330, 220, 30);
        pengembalian.setBounds(65, 430, 240, 40);
        back.setBounds(65, 490, 115, 30);
        clear.setBounds(190, 490, 115, 30);
        scrollPanePinjam.setBounds(365, 120, 700, 240);
        scrollPanePinjam.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPaneKembali.setBounds(365, 370, 700, 240);
        scrollPaneKembali.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        
        setSize(1100,680);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    
    public String getCari(){
        return txcari.getText();
    }
    
    public String getId(){
        return txid.getText();
    }
}
