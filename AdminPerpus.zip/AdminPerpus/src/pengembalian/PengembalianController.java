
package pengembalian;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.*;
import menuadmin.MenuMVC;

public class PengembalianController {
    PengembalianModel model;
    PengembalianView view;
    PengembalianDAO dao;
    
    public PengembalianController(PengembalianModel model, PengembalianView view, 
            PengembalianDAO dao){
        this.model = model;
        this.view = view;
        this.dao = dao;
        
        if ((dao.getJmldataPinjam() != 0) || (dao.getJmldataKembali() != 0)){
            String dataPinjam[][] = dao.readPinjam();
            String dataKembali[][] = dao.readKembali();
            view.tabelPinjam.setModel((new JTable(dataPinjam, view.namaKolomPinjam)).getModel());
            view.tabelKembali.setModel((new JTable(dataKembali, view.namaKolomKembali)).getModel());
        }else{
            JOptionPane.showMessageDialog(null, "Data Tidak Ada");
        }
        
        view.tabelPinjam.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent me){
		int pilih = view.tabelPinjam.getSelectedRow();
                    if(pilih == -1)
                        {
                            return;
			}
                    else{
                    String id = (String) view.tabelPinjam.getValueAt(pilih, 0);
                    view.txid.setText(id);
                    String judul = (String) view.tabelPinjam.getValueAt(pilih, 1);
                    view.txjudul.setText(judul);
                    String pengarang = (String) view.tabelPinjam.getValueAt(pilih, 2);
                    view.txpengarang.setText(pengarang);
                    String nama_user = (String) view.tabelPinjam.getValueAt(pilih, 3);
                    view.txnama.setText(nama_user);
                    String telepon = (String) view.tabelPinjam.getValueAt(pilih, 4);
                    view.txtelepon.setText(telepon);
                    }
            }
	});
        
         view.pengembalian.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
              int id = Integer.parseInt(view.getId());
              model.setIdPeminjaman(id);
              dao.Update(model);
              view.txid.setText("");
              view.txjudul.setText("");
              view.txpengarang.setText("");
              view.txnama.setText("");
              view.txtelepon.setText("");
              String dataPinjam[][] = dao.readPinjam();
              String dataKembali[][] = dao.readKembali();
              view.tabelPinjam.setModel((new JTable(dataPinjam, view.namaKolomPinjam)).getModel());
              view.tabelKembali.setModel((new JTable(dataKembali, view.namaKolomKembali)).getModel());
            }
        });

        
        view.cariPinjam.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
              String cari = view.getCari();
              model.setCari(cari);
              String dataPinjam[][] = dao.CariPinjam(model);
              view.tabelPinjam.setModel((new JTable(dataPinjam, view.namaKolomPinjam)).getModel());
            }
        });
        
        view.cariKembali.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
              String cari = view.getCari();
              model.setCari(cari);
              String dataKembali[][] = dao.CariKembali(model);
              view.tabelKembali.setModel((new JTable(dataKembali, view.namaKolomKembali)).getModel());
            }
        });
        
        view.cariRefresh.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
              view.txcari.setText("");
              String dataPinjam[][] = dao.readPinjam();
              String dataKembali[][] = dao.readKembali();
              view.tabelPinjam.setModel((new JTable(dataPinjam, view.namaKolomPinjam)).getModel());
              view.tabelKembali.setModel((new JTable(dataKembali, view.namaKolomKembali)).getModel());
            }
        });
        
        view.clear.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                view.txid.setText("");
                view.txjudul.setText("");
                view.txpengarang.setText("");
                view.txnama.setText("");
                view.txtelepon.setText("");
            }
        });
        
        view.back.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                view.setVisible(false);
                new MenuMVC();
            }
        });
    }
}
