
package peminjaman;

public class PeminjamanMVC {
    PeminjamanView bukuview = new PeminjamanView();
    PeminjamanModel bukumodel = new PeminjamanModel();
    PeminjamanDAO bukudao = new PeminjamanDAO();
    PeminjamanController bukucontrol = new PeminjamanController(bukumodel, bukuview, bukudao);
}
