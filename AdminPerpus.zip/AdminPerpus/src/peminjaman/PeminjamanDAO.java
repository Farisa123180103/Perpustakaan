
package peminjaman;

import java.sql.*;
import java.util.Random;
import javax.swing.JOptionPane;

public class PeminjamanDAO {
    Connection koneksi;
    Statement statement;
    
    public PeminjamanDAO(){
         try{
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost/perpustakaan";
            koneksi = DriverManager.getConnection(url, "root", "");
            statement = koneksi.createStatement();
        }catch(ClassNotFoundException ex){
            JOptionPane.showMessageDialog(null, "Class Not found : " + ex);
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "SQL Exception : " + ex);
        }
    }
    
    public void Insert(PeminjamanModel Model){
        try{
            Random idRandom = new Random();
            int id_peminjaman = 1000000 + idRandom.nextInt( 9999999 );
            int id_buku = Integer.parseInt(Model.getIdBuku());
            int id_user = Integer.parseInt(Model.getIdUser());
            String status = "Dipinjam";
            String query = "INSERT INTO peminjaman_buku VALUES ('"+id_peminjaman+"','"+id_buku+
                    "','"+id_user+"','"+Model.getJudulBuku()+"','"+Model.getPengarang()+
                    "','"+Model.getGenre()+"','"+Model.getNamaUser()+"','"+Model.getTelepon()+
                    "','"+status+"')";
            String buku = "SELECT * FROM buku WHERE id_buku = "+id_buku;
            ResultSet resultSet = statement.executeQuery(buku);
            if (resultSet.next()){
                int q = resultSet.getInt("stok");
                int sb = q-1;
                String stok = "UPDATE buku SET stok = "+sb+" WHERE id_buku="+id_buku;
                statement.executeUpdate(stok);
            }
            statement.executeUpdate(query);
            JOptionPane.showMessageDialog(null, "Data disimpan");
        }catch(Exception sql){
            JOptionPane.showMessageDialog(null, sql.getMessage());
        }
    }
    
    public String[][] readBuku(){
        try{
            int jmlData = 0;
            String data[][] = new String[getJmldataBuku()][8];
            String query = "SELECT * FROM buku";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                data[jmlData][0] = resultSet.getString("id_buku");
                data[jmlData][1] = resultSet.getString("judul_buku");
                data[jmlData][2] = resultSet.getString("genre");
                data[jmlData][3] = resultSet.getString("pengarang");
                data[jmlData][4] = resultSet.getString("penerbit");
                data[jmlData][5] = resultSet.getString("tahun");
                data[jmlData][6] = resultSet.getString("stok");
                jmlData++;
            }
            return data;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return null;
        }
    }
    
    public String[][] readUser(){
        try{
            int jmlData = 0;
            String data[][] = new String[getJmldataUser()][8];
            String query = "SELECT * FROM user";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                data[jmlData][0] = resultSet.getString("id_user");
                data[jmlData][1] = resultSet.getString("nama_user");
                data[jmlData][2] = resultSet.getString("no_telepon");
                jmlData++;
            }
            return data;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return null;
        }
    }
    
    
    public String[][] CariBuku(PeminjamanModel Model){
        try{
            int jmlData = 0;
            String data[][] = new String[getJmldataCariBuku(Model)][8];
            String query = "SELECT * FROM buku WHERE judul_buku LIKE '%"+Model.getCari()+"%'";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                data[jmlData][0] = resultSet.getString("id_buku");
                data[jmlData][1] = resultSet.getString("judul_buku");
                data[jmlData][2] = resultSet.getString("genre");
                data[jmlData][3] = resultSet.getString("pengarang");
                data[jmlData][4] = resultSet.getString("penerbit");
                data[jmlData][5] = resultSet.getString("tahun");
                data[jmlData][6] = resultSet.getString("stok");
                jmlData++;
            }
            return data;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return null;
        }
    }
    
    public String[][] CariUser(PeminjamanModel Model){
        try{
            int jmlData = 0;
            String data[][] = new String[getJmldataCariUser(Model)][8];
            String query = "SELECT * FROM user WHERE nama_user LIKE '%"+Model.getCari()+"%'";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                data[jmlData][0] = resultSet.getString("id_user");
                data[jmlData][1] = resultSet.getString("nama_user");
                data[jmlData][2] = resultSet.getString("no_telepon");
                jmlData++;
            }
            return data;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return null;
        }
    }
    
    public int getJmldataBuku(){
        int jmlData = 0;
        try{
            String query = "SELECT * FROM buku";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                jmlData++;
            }
             return jmlData;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return 0;
        }
    }
    
    public int getJmldataUser(){
        int jmlData = 0;
        try{
            String query = "SELECT * FROM user";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                jmlData++;
            }
             return jmlData;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return 0;
        }
    }
    
    public int getJmldataCariBuku(PeminjamanModel Model){
        int jmlData = 0;
        try{
            String query = "SELECT * FROM buku WHERE judul_buku LIKE '%"+Model.getCari()+"%'";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                jmlData++;
            }
             return jmlData;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return 0;
        }
    }
    
    public int getJmldataCariUser(PeminjamanModel Model){
        int jmlData = 0;
        try{
            String query = "SELECT * FROM user WHERE nama_user LIKE '%"+Model.getCari()+"%'";
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                jmlData++;
            }
             return jmlData;
        }catch(SQLException e){
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return 0;
        }
    }
    
}
