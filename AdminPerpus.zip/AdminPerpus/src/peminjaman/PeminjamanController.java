
package peminjaman;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.*;
import menuadmin.MenuMVC;
import datapeminjaman.TabelPeminjamanMVC;

public class PeminjamanController {
    PeminjamanModel peminjamanmodel;
    PeminjamanView peminjamanview;
    PeminjamanDAO peminjamandao;
    
    public PeminjamanController(PeminjamanModel peminjamanmodel, PeminjamanView peminjamanview, 
            PeminjamanDAO peminjamandao ){
        this.peminjamanmodel = peminjamanmodel;
        this.peminjamanview = peminjamanview;
        this.peminjamandao = peminjamandao;
        
        if ((peminjamandao.getJmldataBuku() != 0) || (peminjamandao.getJmldataUser() != 0)){
            String dataBuku[][] = peminjamandao.readBuku();
            String dataUser[][] = peminjamandao.readUser();
            peminjamanview.tabelBuku.setModel((new JTable(dataBuku, peminjamanview.namaKolomBuku)).getModel());
            peminjamanview.tabelUser.setModel((new JTable(dataUser, peminjamanview.namaKolomUser)).getModel());
        }else{
            JOptionPane.showMessageDialog(null, "Data Tidak Ada");
        }
        
        peminjamanview.tabelBuku.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent me){
		int pilih = peminjamanview.tabelBuku.getSelectedRow();
                String cek = (String) peminjamanview.tabelBuku.getValueAt(pilih, 6);
                int stok = Integer.parseInt(cek);
                    if(pilih == -1)
                        {
                            return;
			}
                    else if(stok<=0){
                        JOptionPane.showMessageDialog(null, "Stok Habis");
                    }
                    else{
                    String id_buku = (String) peminjamanview.tabelBuku.getValueAt(pilih, 0);
                    peminjamanview.txid_buku.setText(id_buku);
                    String judul_buku = (String) peminjamanview.tabelBuku.getValueAt(pilih, 1);
                    peminjamanview.txjudul_buku.setText(judul_buku);
                    String genre = (String) peminjamanview.tabelBuku.getValueAt(pilih, 2);
                    peminjamanview.txgenre.setText(genre);
                    String pengarang = (String) peminjamanview.tabelBuku.getValueAt(pilih, 3);
                    peminjamanview.txpengarang.setText(pengarang);
                    }
            }
	});
        
        peminjamanview.tabelUser.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent me){
		int pilih = peminjamanview.tabelUser.getSelectedRow();
                    if(pilih == -1)
                        {
                            return;
			}
                    else{
                    String id_user = (String) peminjamanview.tabelUser.getValueAt(pilih, 0);
                    peminjamanview.txid_user.setText(id_user);
                    String nama_user = (String) peminjamanview.tabelUser.getValueAt(pilih, 1);
                    peminjamanview.txnama_user.setText(nama_user);
                    String telepon = (String) peminjamanview.tabelUser.getValueAt(pilih, 2);
                    peminjamanview.txtelepon.setText(telepon);
                    }
            }
	});
        
        peminjamanview.input.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
              String id_buku = peminjamanview.getIdBuku();
              String judul_buku = peminjamanview.getJudulBuku();
              String pengarang = peminjamanview.getPengarang();
              String genre = peminjamanview.getGenre();
              String id_user = peminjamanview.getIdUser();
              String nama_user = peminjamanview.getNamaUser();
              String telepon = peminjamanview.getTelepon();
              if(id_buku.isEmpty()||judul_buku.isEmpty()||pengarang.isEmpty()||genre.isEmpty()
                      ||id_user.isEmpty()||nama_user.isEmpty()||telepon.isEmpty()){
                  JOptionPane.showMessageDialog(null, "Harap isi semua field");
              }else{
                  peminjamanmodel.setPeminjamanModel(id_buku, judul_buku, pengarang, genre, 
                          id_user, nama_user, telepon);
                  peminjamandao.Insert(peminjamanmodel);
                  String dataBuku[][] = peminjamandao.readBuku();
                  peminjamanview.tabelBuku.setModel((new JTable(dataBuku, peminjamanview.namaKolomBuku)).getModel());
                  peminjamanview.txid_buku.setText("");
                  peminjamanview.txjudul_buku.setText("");
                  peminjamanview.txpengarang.setText("");
                  peminjamanview.txgenre.setText("");
                  peminjamanview.txid_user.setText("");
                  peminjamanview.txnama_user.setText("");
                  peminjamanview.txtelepon.setText("");
              }
            }
        });
        
        peminjamanview.cariBuku.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
              String cari = peminjamanview.getCari();
              peminjamanmodel.setCari(cari);
              String dataBuku[][] = peminjamandao.CariBuku(peminjamanmodel);
              peminjamanview.tabelBuku.setModel((new JTable(dataBuku, peminjamanview.namaKolomBuku)).getModel());
            }
        });
        
        peminjamanview.cariUser.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
              String cari = peminjamanview.getCari();
              peminjamanmodel.setCari(cari);
              String dataUser[][] = peminjamandao.CariUser(peminjamanmodel);
              peminjamanview.tabelUser.setModel((new JTable(dataUser, peminjamanview.namaKolomUser)).getModel());
            }
        });
        
        peminjamanview.cariRefresh.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
              peminjamanview.txcari.setText("");
              String dataBuku[][] = peminjamandao.readBuku();
              String dataUser[][] = peminjamandao.readUser();
              peminjamanview.tabelBuku.setModel((new JTable(dataBuku, peminjamanview.namaKolomBuku)).getModel());
              peminjamanview.tabelUser.setModel((new JTable(dataUser, peminjamanview.namaKolomUser)).getModel());
            }
        });
        
        peminjamanview.back.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                peminjamanview.setVisible(false);
                new MenuMVC();
            }
        });
        
        peminjamanview.clear.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                peminjamanview.txid_buku.setText("");
                peminjamanview.txjudul_buku.setText("");
                peminjamanview.txpengarang.setText("");
                peminjamanview.txgenre.setText("");
                peminjamanview.txid_user.setText("");
                peminjamanview.txnama_user.setText("");
                peminjamanview.txtelepon.setText("");
            }
        });
        peminjamanview.openTable.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                new TabelPeminjamanMVC();
            }
        });
    }
}
