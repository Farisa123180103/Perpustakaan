
package peminjaman;

public class PeminjamanModel {
    private String id_buku, judul_buku, pengarang, genre, id_user, nama_user, telepon, cari;
    private int id_peminjaman;
    
    public void setPeminjamanModel(String nid_buku, String njudul_buku, String npengarang, 
            String ngenre, String nid_user, String nnama_user, String telepon){
        this.id_buku = nid_buku;
        this.judul_buku = njudul_buku;
        this.pengarang = npengarang;
        this.genre = ngenre;
        this.id_user = nid_user;
        this.nama_user = nnama_user;
        this.telepon = telepon;
    }
    public void setCari(String ncari){
         this.cari = ncari;
    }
    public void setIdPeminjaman(int nid_peminjaman){
         this.id_peminjaman = nid_peminjaman;
    }
    
    public String getIdBuku(){
        return id_buku;
    }
    public void getIdBuku(String id_buku){
        this.id_buku = id_buku;
    }
    public String getJudulBuku(){
        return judul_buku;
    }
    public void getJudulBuku(String judul_buku){
        this.judul_buku = judul_buku;
    }
    public String getPengarang(){
        return pengarang;
    }
    public void getPengarang(String pengarang){
        this.pengarang = pengarang;
    }
    public String getGenre(){
        return genre;
    }
    public void getGenre(String genre){
        this.genre = genre;
    }
    public String getIdUser(){
        return id_user;
    }
    public void getIdUser(String id_user){
        this.id_user = id_user;
    }
    public void getNamaUser(String nama_user){
        this.nama_user = nama_user;
    }
    public String getNamaUser(){
        return nama_user;
    }
    public void getTelepon(String telepon){
        this.telepon = telepon;
    }
    public String getTelepon(){
        return telepon;
    }
    public String getCari(){
        return cari;
    }
    public void getCari(String cari){
        this.cari = cari;
    }
    public int getIdPeminjaman(){
        return id_peminjaman;
    }
    public void getIdPeminjaman(int id_peminjaman){
        this.id_peminjaman = id_peminjaman;
    }
}
