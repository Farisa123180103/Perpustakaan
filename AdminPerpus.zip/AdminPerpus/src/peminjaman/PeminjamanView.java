
package peminjaman;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

class PeminjamanView extends JFrame{
    JLabel judul, info_buku, info_user, id_user, id_buku, judul_buku, pengarang, genre, nama_user, telepon;
    JTextField txid_user, txid_buku, txjudul_buku, txpengarang, txgenre, txnama_user, txtelepon, txcari;
    JButton cariUser, cariBuku, cariRefresh, input, openTable, back, clear;
    JTable tabelUser, tabelBuku;
    DefaultTableModel tableModelUser, tableModelBuku;
    JScrollPane scrollPaneUser, scrollPaneBuku;
    Object namaKolomBuku[] = {"ID Buku","Judul Buku","Genre","Pengarang","Penerbit","Tahun Terbit","Stok"};
    Object namaKolomUser[] = {"ID User","Nama","No. Telepon",};
    
    public PeminjamanView(){
        Image image = new ImageIcon(getClass().getResource("bg6.jpg")).getImage();
         this.setContentPane(new JPanel() {
         @Override
            public void paintComponent(Graphics g) {
               super.paintComponent(g);
               g.drawImage(image, 0, 0, 1100,680, null);
            }
         }); 
        setTitle("Pemrosesan Data Peminjaman Buku");
        
        tableModelUser = new DefaultTableModel(namaKolomUser, 0);
        tabelUser = new JTable(tableModelUser);
        scrollPaneUser = new JScrollPane(tabelUser);
        tableModelBuku = new DefaultTableModel(namaKolomBuku, 0);
        tabelBuku = new JTable(tableModelBuku);
        scrollPaneBuku = new JScrollPane(tabelBuku);
        
        judul = new JLabel("PEMROSESAN DATA PEMINJAMAN BUKU");
        info_buku = new JLabel("----      Data Buku      ----");
        id_buku = new JLabel("ID Buku");
        judul_buku = new JLabel("Judul Buku");
        pengarang = new JLabel("Pengarang");
        genre = new JLabel("Genre");
        info_user = new JLabel("------ Data Peminjam ------");
        id_user = new JLabel("ID User");
        nama_user = new JLabel("Nama");
        telepon = new JLabel("Telepon");
        Font font2 = new Font("Comic Sans MS", 1, 16);
        Font font = new Font("Tahoma", 1, 14);
        Font font1 = new Font("Cooper Black", 1, 26);
        judul_buku.setFont(font);
        pengarang.setFont(font);
        id_buku.setFont(font);
        genre.setFont(font);
        info_buku.setFont(font2);
        judul.setFont(font1);
        info_user.setFont(font2);
        id_user.setFont(font);
        nama_user.setFont(font);
        telepon.setFont(font);
        
        judul_buku.setForeground(Color.WHITE);
        pengarang.setForeground(Color.WHITE);
        genre.setForeground(Color.WHITE);
        info_buku.setForeground(Color.WHITE);
        judul.setForeground(Color.WHITE);
        info_user.setForeground(Color.WHITE);
        id_user.setForeground(Color.WHITE);
        nama_user.setForeground(Color.WHITE);
        telepon.setForeground(Color.WHITE);
        
        txcari = new JTextField();
        txid_buku = new JTextField();
        txjudul_buku = new JTextField();
        txpengarang = new JTextField();
        txgenre = new JTextField();
        txid_user = new JTextField();
        txnama_user = new JTextField();
        txtelepon = new JTextField();
        
        txid_buku.setEditable(false);
        txjudul_buku.setEditable(false);
        txpengarang.setEditable(false);
        txgenre.setEditable(false);
        txid_user.setEditable(false);
        txnama_user.setEditable(false);
        
        cariUser = new JButton("Cari User");
        cariBuku = new JButton("Cari Buku");
        cariRefresh = new JButton("Refresh Pencarian");
        input = new JButton("Input");
        openTable = new JButton("Data Peminjaman");
        back = new JButton("Back");
        clear = new JButton("Clear");
        
        setLayout(null);
        add(scrollPaneBuku);
        add(scrollPaneUser);
        add(judul);
        add(info_buku);
        add(info_user);
        add(id_user);
        add(id_buku);
        add(judul_buku);
        add(pengarang);
        add(genre);
        add(nama_user);
        add(telepon);
        add(txid_user);
        add(txid_buku);
        add(txjudul_buku);
        add(txpengarang);
        add(txgenre);
        add(txnama_user);
        add(txtelepon);
        add(txcari);
        add(cariUser);
        add(cariBuku);
        add(cariRefresh);
        add(input);
        add(openTable);
        add(back);
        add(clear);        
        
        judul.setBounds(230, 20, 800, 25);
        info_buku.setBounds(80, 105, 250, 30);
        id_buku.setBounds(20, 150, 60, 30);
        txid_buku.setBounds(100, 150, 240, 30);
        judul_buku.setBounds(20, 190, 100, 30);
        txjudul_buku.setBounds(100, 190, 240, 30);
        pengarang.setBounds(20, 230, 100, 30);
        txpengarang.setBounds(100, 230, 240, 30);
        genre.setBounds(20, 270, 100, 30);
        txgenre.setBounds(100, 270, 240, 30);
        info_user.setBounds(80, 320, 250, 30);
        id_user.setBounds(20, 365, 60, 30);
        txid_user.setBounds(100, 365, 240, 30);
        id_user.setBounds(20, 365, 60, 30);
        txid_user.setBounds(100, 365, 240, 30);
        nama_user.setBounds(20, 405, 60, 30);
        txnama_user.setBounds(100, 405, 240, 30);
        telepon.setBounds(20, 445, 60, 30);
        txtelepon.setBounds(100, 445, 240, 30);
        input.setBounds(20, 500, 140, 30);
        clear.setBounds(170, 500, 140, 30);
        openTable.setBounds(170, 540, 140, 30);
        back.setBounds(20, 540, 140, 30);
        txcari.setBounds(365, 80, 260, 30);
        cariUser.setBounds(635, 80, 140, 30);
        cariBuku.setBounds(780, 80, 140, 30);
        cariRefresh.setBounds(925, 80, 140, 30);
        scrollPaneBuku.setBounds(365, 120, 700, 240);
        scrollPaneBuku.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPaneUser.setBounds(365, 370, 700, 240);
        scrollPaneUser.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        
        setSize(1100,680);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    
    public String getCari(){
        return txcari.getText();
    }
    
    public String getIdBuku(){
        return txid_buku.getText();
    }
    
    public String getJudulBuku(){
        return txjudul_buku.getText();
    }
    
    public String getPengarang(){
        return txpengarang.getText();
    }
    
    public String getGenre(){
        return txgenre.getText();
    }
    
    public String getIdUser(){
        return txid_user.getText();
    }
    
    public String getNamaUser(){
        return txnama_user.getText();
    }
    
    public String getTelepon(){
        return txtelepon.getText();
    }
    
}
